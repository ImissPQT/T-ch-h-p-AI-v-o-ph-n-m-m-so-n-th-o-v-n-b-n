# -*- coding: utf-8 -*-
"""Chuyển Markdown sang văn bản thuần dễ đọc cho ô lịch sử chat (ô AWT không hiển thị được định dạng).

Bản Markdown gốc vẫn được giữ trong phiên hội thoại để giai đoạn 6 chèn vào Writer với định dạng thật.
"""
import re

_BOLD = re.compile(r"(\*\*|__)(?=\S)(.+?)(?<=\S)\1")
_ITALIC_STAR = re.compile(r"(?<![\w*])\*(?=\S)(.+?)(?<=\S)\*(?![\w*])")
_ITALIC_UND = re.compile(r"(?<![\w_])_(?=\S)(.+?)(?<=\S)_(?![\w_])")
_STRIKE = re.compile(r"~~(.+?)~~")
_CODE = re.compile(r"`([^`]+)`")
_LINK = re.compile(r"!?\[([^\]]*)\]\(([^)\s]+)[^)]*\)")
_HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")
_BULLET = re.compile(r"^(\s*)[-*+]\s+(.*)$")
_TASK = re.compile(r"^\[( |x|X)\]\s+")
_HR = re.compile(r"^\s*([-*_])(\s*\1){2,}\s*$")
_TABLE_SEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")
_FENCE = re.compile(r"^\s*(```|~~~)\s*([\w+#.-]*)\s*$")


def _inline(s):
    codes = []

    def keep(m):
        codes.append(m.group(1))
        return "\x00%d\x00" % (len(codes) - 1)

    s = _CODE.sub(keep, s)  # bảo vệ code inline khỏi xử lý in đậm/nghiêng
    s = _LINK.sub(lambda m: m.group(1) + " <" + m.group(2) + ">" if m.group(1) else m.group(2), s)
    s = _BOLD.sub(r"\2", s)
    s = _ITALIC_STAR.sub(r"\1", s)
    s = _ITALIC_UND.sub(r"\1", s)
    s = _STRIKE.sub(r"\1", s)
    return re.sub("\x00(\\d+)\x00", lambda m: "‘" + codes[int(m.group(1))] + "’", s)


def to_plain(md):
    out = []
    in_code = False
    fence = ""
    for line in (md or "").replace("\r\n", "\n").split("\n"):
        m = _FENCE.match(line)
        if m and (not in_code or m.group(1) == fence):
            if not in_code:
                in_code, fence = True, m.group(1)
                out.append("┌── " + (m.group(2) or "code"))
            else:
                in_code = False
                out.append("└──")
            continue
        if in_code:
            out.append("│ " + line)
            continue
        if _HR.match(line):
            out.append("────────────")
            continue
        m = _HEADING.match(line)
        if m:
            level, text = len(m.group(1)), _inline(m.group(2))
            out.append(("■ " if level <= 2 else "▸ ") + text)
            continue
        if _TABLE_SEP.match(line) and "-" in line:
            continue
        m = _BULLET.match(line)
        if m:
            indent, text = m.group(1), m.group(2)
            t = _TASK.match(text)
            if t:
                text = ("☑ " if t.group(1) in "xX" else "☐ ") + text[t.end():]
            out.append("  " * (len(indent.replace("\t", "  ")) // 2) + "• " + _inline(text))
            continue
        if line.lstrip().startswith(">"):
            out.append("│ " + _inline(line.lstrip()[1:].lstrip()))
            continue
        if line.strip().startswith("|") and line.strip().endswith("|"):
            cells = [_inline(c.strip()) for c in line.strip()[1:-1].split("|")]
            out.append(" │ ".join(cells))
            continue
        out.append(_inline(line))
    if in_code:
        out.append("└──")
    return "\n".join(out).strip("\n")
