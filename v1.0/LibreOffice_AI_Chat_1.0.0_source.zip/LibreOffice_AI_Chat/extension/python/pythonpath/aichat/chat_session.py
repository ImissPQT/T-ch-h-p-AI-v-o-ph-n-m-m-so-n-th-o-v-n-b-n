# -*- coding: utf-8 -*-
"""Phiên hội thoại: giữ ngữ cảnh, tách biệt giữa các phiên, cắt bớt lịch sử khi quá dài."""
import itertools

_ids = itertools.count(1)


class ChatSession(object):
    def __init__(self):
        self.id = next(_ids)
        # Mỗi mục: {"role": "user"|"model"|"note", "text": str, "model": str}
        # "note" = thông báo hệ thống (lỗi, ghi chú) -> chỉ hiển thị, KHÔNG gửi cho Gemini.
        self.items = []

    def add(self, role, text, model=""):
        item = {"role": role, "text": text, "model": model}
        self.items.append(item)
        return item

    def remove(self, item):
        if item in self.items:
            self.items.remove(item)

    def build_contents(self, char_budget):
        """Danh sách `contents` cho Gemini: các lượt user/model gần nhất nằm trong ngân sách ký tự.

        Luôn giữ tin nhắn cuối của người dùng; bắt đầu bằng lượt 'user' như Gemini yêu cầu.
        """
        turns = [i for i in self.items if i["role"] in ("user", "model") and i["text"]]
        picked, used = [], 0
        for it in reversed(turns):
            n = len(it["text"])
            if picked and used + n > char_budget:
                break
            picked.append(it)
            used += n
        picked.reverse()
        while picked and picked[0]["role"] != "user":
            picked.pop(0)
        trimmed = len(picked) < len(turns)
        contents = [{"role": i["role"], "parts": [{"text": i["text"]}]} for i in picked]
        return contents, trimmed
