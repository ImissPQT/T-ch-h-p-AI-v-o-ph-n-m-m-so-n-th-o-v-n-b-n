# -*- coding: utf-8 -*-
"""Sao chép văn bản vào Clipboard hệ thống qua UNO (dùng chung clipboard với Windows)."""
import uno
import unohelper
from com.sun.star.datatransfer import XTransferable, DataFlavor

_FLAVOR = "text/plain;charset=utf-16"


class _TextTransferable(unohelper.Base, XTransferable):
    def __init__(self, text):
        self._text = text
        f = DataFlavor()
        f.MimeType = _FLAVOR
        f.HumanPresentableName = "Unicode Text"
        f.DataType = uno.getTypeByName("string")
        self._flavors = (f,)

    def getTransferData(self, flavor):
        if flavor.MimeType == _FLAVOR:
            return self._text
        raise Exception("Unsupported flavor")

    def getTransferDataFlavors(self):
        return self._flavors

    def isDataFlavorSupported(self, flavor):
        return flavor.MimeType == _FLAVOR


def copy_text(ctx, text):
    """Ném lỗi nếu không ghi được clipboard (phía gọi hiển thị thông báo)."""
    cb = ctx.ServiceManager.createInstanceWithContext("com.sun.star.datatransfer.clipboard.SystemClipboard", ctx)
    # Windows dùng \r\n cho xuống dòng trong clipboard văn bản
    cb.setContents(_TextTransferable(text.replace("\r\n", "\n").replace("\n", "\r\n")), None)


def read_text(ctx):
    """Đọc lại clipboard (dùng để kiểm tra)."""
    cb = ctx.ServiceManager.createInstanceWithContext("com.sun.star.datatransfer.clipboard.SystemClipboard", ctx)
    t = cb.getContents()
    for f in t.getTransferDataFlavors():
        if f.MimeType.startswith("text/plain") and "utf-16" in f.MimeType:
            return t.getTransferData(f)
    return None
