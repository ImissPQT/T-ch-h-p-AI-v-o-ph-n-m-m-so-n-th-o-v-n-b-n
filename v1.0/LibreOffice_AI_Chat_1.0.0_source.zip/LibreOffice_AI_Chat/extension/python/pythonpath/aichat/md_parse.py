# -*- coding: utf-8 -*-
"""Phân tích Markdown phổ biến thành các khối có cấu trúc để chèn vào Writer với định dạng thật.

Khối: {"type": "para"|"heading"|"bullet"|"ordered"|"code"|"quote", ...}
Đoạn chữ (runs): [(text, {"b":bool,"i":bool,"s":bool,"code":bool,"link":url})]

Quy ước: mỗi dòng khác rỗng ngoài khối code là MỘT đoạn văn trong Writer
(giống cách Writer tách đoạn; AI hầu như không ngắt dòng giữa câu).
"""
import re

_FENCE = re.compile(r"^\s*(```|~~~)\s*([\w+#.-]*)\s*$")
_HEADING = re.compile(r"^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$")
_BULLET = re.compile(r"^(\s*)[-*+]\s+(.*)$")
_ORDERED = re.compile(r"^(\s*)(\d{1,9})[.)]\s+(.*)$")
_HR = re.compile(r"^\s*([-*_])(\s*\1){2,}\s*$")
_TABLE_SEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")
_TASK = re.compile(r"^\[( |x|X)\]\s+")

# Inline: thứ tự ưu tiên khi hai mẫu bắt đầu cùng vị trí
_INLINE = [
    ("code", re.compile(r"`([^`\n]+)`")),
    ("link", re.compile(r"\[([^\]\n]+)\]\((\S+?)(?:\s+\"[^\"]*\")?\)")),
    ("bi", re.compile(r"\*\*\*(?=\S)(.+?)(?<=\S)\*\*\*")),
    ("b", re.compile(r"\*\*(?=\S)(.+?)(?<=\S)\*\*")),
    ("b", re.compile(r"(?<![\w_])__(?=\S)(.+?)(?<=\S)__(?![\w_])")),
    ("s", re.compile(r"~~(?=\S)(.+?)(?<=\S)~~")),
    ("i", re.compile(r"(?<![\w*])\*(?=[^\s*])(.+?)(?<=[^\s*])\*(?![\w*])")),
    ("i", re.compile(r"(?<![\w_])_(?=[^\s_])(.+?)(?<=[^\s_])_(?![\w_])")),
]
_ESC = re.compile(r"\\([\\`*_{}\[\]()#+\-.!~|>])")


def _flags(**kw):
    f = {"b": False, "i": False, "s": False, "code": False, "link": ""}
    f.update(kw)
    return f


def parse_inline(text, base=None):
    base = base or _flags()
    # ký tự thoát \* \_ ... -> giữ nguyên ký tự (dùng ký tự riêng để không bị hiểu nhầm là định dạng)
    escapes = []

    def keep(m):
        escapes.append(m.group(1))
        return "\x01%d\x01" % (len(escapes) - 1)

    text = _ESC.sub(keep, text)
    runs = _inline(text, base)
    out = []
    for t, f in runs:
        t = re.sub("\x01(\\d+)\x01", lambda m: escapes[int(m.group(1))], t)
        if not t:
            continue
        if out and out[-1][1] == f:
            out[-1] = (out[-1][0] + t, f)  # gộp các đoạn cùng định dạng
        else:
            out.append((t, f))
    return out


def _inline(text, f):
    runs = []
    pos = 0
    while pos < len(text):
        best = None
        for kind, rx in _INLINE:
            m = rx.search(text, pos)
            if m and (best is None or m.start() < best[1].start()):
                best = (kind, m)
        if best is None:
            break
        kind, m = best
        if m.start() > pos:
            runs.append((text[pos:m.start()], f))
        g = dict(f)
        if kind == "code":
            g["code"] = True
            runs.append((m.group(1), g))           # code: giữ nguyên, không xử lý tiếp
        elif kind == "link":
            g["link"] = m.group(2)
            runs.extend(_inline(m.group(1), g))
        else:
            if kind in ("b", "bi"):
                g["b"] = True
            if kind in ("i", "bi"):
                g["i"] = True
            if kind == "s":
                g["s"] = True
            runs.extend(_inline(m.group(1), g))
        pos = m.end()
    if pos < len(text):
        runs.append((text[pos:], f))
    return runs


def _level(indent):
    return min(len(indent.replace("\t", "    ")) // 2, 8)


def parse_blocks(md):
    blocks = []
    lines = (md or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        m = _FENCE.match(line)
        if m:
            fence, code = m.group(1), []
            i += 1
            while i < len(lines) and not (lines[i].strip().startswith(fence) and lines[i].strip().strip(fence[0]) == ""):
                code.append(lines[i])
                i += 1
            i += 1  # bỏ dòng đóng ``` (nếu thiếu thì coi như hết khối)
            blocks.append({"type": "code", "lang": m.group(2), "lines": code or [""]})
            continue
        i += 1
        if not line.strip() or _HR.match(line):
            continue
        m = _HEADING.match(line)
        if m:
            blocks.append({"type": "heading", "level": len(m.group(1)), "runs": parse_inline(m.group(2))})
            continue
        if _TABLE_SEP.match(line) and "-" in line:
            continue
        m = _ORDERED.match(line)
        if m:
            blocks.append({"type": "ordered", "level": _level(m.group(1)), "start": int(m.group(2)),
                           "runs": parse_inline(m.group(3))})
            continue
        m = _BULLET.match(line)
        if m:
            text = m.group(2)
            t = _TASK.match(text)
            if t:
                text = ("☑ " if t.group(1) in "xX" else "☐ ") + text[t.end():]
            blocks.append({"type": "bullet", "level": _level(m.group(1)), "runs": parse_inline(text)})
            continue
        s = line.strip()
        if s.startswith(">"):
            blocks.append({"type": "quote", "runs": parse_inline(s.lstrip(">").strip())})
            continue
        if s.startswith("|") and s.endswith("|") and len(s) > 1:
            cells = [c.strip() for c in s[1:-1].split("|")]
            blocks.append({"type": "para", "runs": parse_inline("\t".join(cells))})
            continue
        blocks.append({"type": "para", "runs": parse_inline(s)})
    return blocks


def is_inline(blocks):
    """Một đoạn văn thường duy nhất -> chèn ngay tại chỗ, không tách đoạn."""
    return len(blocks) == 1 and blocks[0]["type"] == "para"
