# -*- coding: utf-8 -*-
"""Cài đặt KHÔNG bí mật (mô hình, system prompt...) lưu dạng JSON trong hồ sơ người dùng LibreOffice:
Windows: %APPDATA%\\LibreOffice\\4\\user\\aichat\\settings.json

API key KHÔNG nằm ở đây (xem secret_store.py).
"""
import json
import os

import uno

from aichat.gemini_client import DEFAULT_MODEL, DEFAULT_TIMEOUT

DEFAULT_SYSTEM_PROMPT = (
    "Bạn là trợ lý AI được tích hợp trong LibreOffice Writer, giúp người dùng soạn thảo, "
    "chỉnh sửa và trả lời câu hỏi. Trả lời bằng ngôn ngữ người dùng đang dùng (mặc định tiếng Việt), "
    "rõ ràng, súc tích. Có thể dùng Markdown cơ bản (tiêu đề, danh sách, in đậm, khối code)."
)

DEFAULTS = {
    "model": DEFAULT_MODEL,
    "system_prompt": DEFAULT_SYSTEM_PROMPT,
    "timeout": DEFAULT_TIMEOUT,
    "history_char_budget": 120000,  # ~30-40k token lịch sử gửi kèm mỗi lượt
    "max_message_chars": 100000,
    "known_models": [],
}


def _settings_path(ctx):
    ps = ctx.ServiceManager.createInstanceWithContext("com.sun.star.util.PathSubstitution", ctx)
    user_dir = uno.fileUrlToSystemPath(ps.substituteVariables("$(user)", True))
    return os.path.join(user_dir, "aichat", "settings.json")


def load(ctx):
    data = dict(DEFAULTS)
    try:
        with open(_settings_path(ctx), "r", encoding="utf-8") as f:
            stored = json.load(f)
        if isinstance(stored, dict):
            for k in DEFAULTS:
                if k in stored and type(stored[k]) == type(DEFAULTS[k]):
                    data[k] = stored[k]
    except (OSError, ValueError):
        pass
    return data


def save(ctx, data):
    path = _settings_path(ctx)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    clean = {k: data.get(k, DEFAULTS[k]) for k in DEFAULTS}
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(clean, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
