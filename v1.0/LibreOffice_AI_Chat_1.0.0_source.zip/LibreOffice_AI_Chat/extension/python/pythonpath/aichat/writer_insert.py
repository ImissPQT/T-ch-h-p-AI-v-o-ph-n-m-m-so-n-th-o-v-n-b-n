# -*- coding: utf-8 -*-
"""Ghi kết quả AI vào tài liệu Writer bằng UNO: chèn tại con trỏ, thay thế vùng gốc.

- Markdown -> định dạng thật: Paragraph Style (Heading 1-6, Preformatted Text, Quotations),
  danh sách Writer thật (List 1 / Numbering 123), in đậm/nghiêng/gạch/code/liên kết.
- Mọi thay đổi được gom vào MỘT nhóm Undo (XUndoManager.enterUndoContext): Ctrl+Z một lần là khôi phục.
- Nếu lỗi giữa chừng: đóng nhóm Undo rồi hoàn tác ngay => tài liệu không bị thay đổi dở dang.
- Chỉ gọi từ main thread (sự kiện nút bấm).
"""
import uno

from aichat.md_parse import is_inline, parse_blocks, parse_inline

MONO = "Liberation Mono"
BOLD = 150.0      # com.sun.star.awt.FontWeight.BOLD
ITALIC = uno.Enum("com.sun.star.awt.FontSlant", "ITALIC")
PARAGRAPH_BREAK = 0  # com.sun.star.text.ControlCharacter.PARAGRAPH_BREAK
BULLET_STYLE = "List 1"          # hiển thị: "Bullet •"
NUMBER_STYLE = "Numbering 123"
CHAR_PROPS = ("CharWeight", "CharPosture", "CharStrikeout", "CharFontName", "CharHeight", "HyperLinkURL")


class EditError(Exception):
    def __init__(self, message):
        Exception.__init__(self, message)
        self.message = message


def utf16_len(s):
    """Writer đếm vị trí theo đơn vị UTF-16 (emoji = 2)."""
    return len(s.encode("utf-16-le")) // 2


# ------------------------------------------------------------------ một bước Undo
def run_as_single_undo(doc, title, fn):
    um = doc.getUndoManager()
    before = len(um.getAllUndoActionTitles())
    doc.lockControllers()
    um.enterUndoContext(title)
    failed = None
    result = None
    try:
        result = fn()
    except Exception as e:
        failed = e
    finally:
        um.leaveUndoContext()
        doc.unlockControllers()
    if failed is not None:
        # Hoàn tác phần đã làm (nếu có) để tài liệu không ở trạng thái dở dang.
        if len(um.getAllUndoActionTitles()) > before and um.getCurrentUndoActionTitle() == title:
            um.undo()
            um.clearRedo()
        if isinstance(failed, EditError):
            raise failed
        raise EditError("Không ghi được vào tài liệu (%s). Tài liệu đã được giữ nguyên." % type(failed).__name__)
    return result


# ------------------------------------------------------------------ chèn Markdown
class _Ctx(object):
    def __init__(self, doc, cursor):
        self.doc = doc
        self.text = cursor.getText()
        num = doc.StyleFamilies.getByName("NumberingStyles")
        para = doc.StyleFamilies.getByName("ParagraphStyles")
        self.has_num = {n: num.hasByName(n) for n in (BULLET_STYLE, NUMBER_STYLE)}
        self.has_para = para.hasByName
        # Phông/cỡ chữ tại vị trí chèn -> chữ thường giữ "giao diện" giống văn bản xung quanh
        self.base_font = cursor.CharFontName
        self.base_height = cursor.CharHeight
        style = cursor.ParaStyleName or "Standard"
        if style.startswith("Heading") or style in ("Title", "Subtitle"):
            style = "Text body" if self.has_para("Text body") else "Standard"
        self.base_style = style


def _insert_run(ctx, cur, text, f, para_kind):
    if not text:
        return
    ctx.text.insertString(cur, text, False)
    cur.goLeft(utf16_len(text), True)          # chọn đúng đoạn vừa chèn để định dạng
    try:
        cur.setPropertiesToDefault(CHAR_PROPS)   # bỏ định dạng "lan" từ chữ bên cạnh
    except Exception:
        pass
    names, values = [], []

    def put(n, v):
        names.append(n)
        values.append(v)

    if para_kind == "code" or f.get("code"):
        put("CharFontName", MONO)
    elif para_kind != "heading":
        put("CharFontName", ctx.base_font)
        put("CharHeight", ctx.base_height)
    if f.get("b"):
        put("CharWeight", BOLD)
    if f.get("i"):
        put("CharPosture", ITALIC)
    if f.get("s"):
        put("CharStrikeout", 1)
    if f.get("link"):
        put("HyperLinkURL", f["link"])
    for n, v in zip(names, values):
        cur.setPropertyValue(n, v)
    cur.collapseToEnd()


def _set_paragraph(ctx, cur, block, prev):
    kind = block["type"]
    style, numbering, level, restart, start = ctx.base_style, "", 0, False, 1
    if kind == "heading":
        style = "Heading %d" % block["level"]
    elif kind == "code":
        style = "Preformatted Text"
    elif kind == "quote":
        style = "Quotations"
    elif kind in ("bullet", "ordered"):
        name = BULLET_STYLE if kind == "bullet" else NUMBER_STYLE
        if ctx.has_num[name]:
            numbering, level = name, block["level"]
            restart = kind == "ordered" and not (prev and prev["type"] == "ordered")
            start = block.get("start", 1)
    if not ctx.has_para(style):
        style = "Standard"
    cur.setPropertyValue("ParaStyleName", style)
    cur.setPropertyValue("NumberingStyleName", numbering)   # "" = bỏ danh sách thừa hưởng từ đoạn trước
    if numbering:
        cur.setPropertyValue("NumberingLevel", level)
        if restart:
            cur.setPropertyValue("ParaIsNumberingRestart", True)
            cur.setPropertyValue("NumberingStartValue", start)


def _fallback_prefix(ctx, block):
    """Không có style danh sách -> thêm ký hiệu thủ công (hiếm khi xảy ra)."""
    if block["type"] == "bullet" and not ctx.has_num[BULLET_STYLE]:
        return "• "
    if block["type"] == "ordered" and not ctx.has_num[NUMBER_STYLE]:
        return "%d. " % block.get("start", 1)
    return ""


def insert_markdown(doc, position, md):
    """Chèn `md` tại `position` (XTextRange, chèn tại điểm đầu). Trả về cursor ở cuối nội dung vừa chèn."""
    blocks = parse_blocks(md)
    if not blocks:
        raise EditError("Câu trả lời không có nội dung để chèn.")
    text = position.getText()
    cur = text.createTextCursorByRange(position.getStart())
    ctx = _Ctx(doc, cur)

    if is_inline(blocks):                       # một câu/đoạn: chèn ngay tại chỗ, không tách đoạn
        # giữ khoảng trắng đầu/cuối dòng (vd. chèn giữa câu), chỉ bỏ ký tự xuống dòng
        for t, f in parse_inline(md.strip("\r\n")):
            _insert_run(ctx, cur, t, f, "para")
        return cur

    # Nhiều khối: tách đoạn hiện tại để nội dung mới nằm ở các đoạn riêng, phần chữ còn lại giữ nguyên
    if not cur.isStartOfParagraph():
        text.insertControlCharacter(cur, PARAGRAPH_BREAK, False)
    if not cur.isEndOfParagraph():
        text.insertControlCharacter(cur, PARAGRAPH_BREAK, False)
        cur.gotoPreviousParagraph(False)
    prev = None
    for idx, block in enumerate(blocks):
        lines = block["lines"] if block["type"] == "code" else [None]
        for j, line in enumerate(lines):
            if idx > 0 or j > 0:
                text.insertControlCharacter(cur, PARAGRAPH_BREAK, False)
            _set_paragraph(ctx, cur, block, prev if j == 0 else block)
            if block["type"] == "code":
                _insert_run(ctx, cur, line, {}, "code")
            else:
                prefix = _fallback_prefix(ctx, block)
                if prefix:
                    _insert_run(ctx, cur, prefix, {}, block["type"])
                for t, f in block["runs"]:
                    _insert_run(ctx, cur, t, f, block["type"])
        prev = block
    return cur


def replace_range(doc, anchor, md):
    """Xóa nội dung của `anchor` rồi chèn `md` vào đúng chỗ đó."""
    anchor.setString("")
    return insert_markdown(doc, anchor, md)
