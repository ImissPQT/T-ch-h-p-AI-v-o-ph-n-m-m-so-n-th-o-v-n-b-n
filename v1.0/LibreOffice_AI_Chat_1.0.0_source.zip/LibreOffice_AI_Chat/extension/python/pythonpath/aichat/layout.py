"""Tính bố cục panel theo pixel để khung chat co giãn theo chiều rộng/cao của Sidebar."""

POSSIZE = 15  # com.sun.star.awt.PosSize.POSSIZE

PAD = 6
GAP = 4
BTN_H = 26
STATUS_H = 18
INPUT_H = 70
SEL_LABEL_H = 22
SEL_PREVIEW_H = 72
MIN_HISTORY_H = 110

# Khối "văn bản đã chọn" (chỉ hiện khi đã đọc vùng chọn)
SEL_CONTROLS = ("lblSel", "btnClearSel", "txtSel", "btnSummarize", "btnExplain", "btnAnalyze",
                "btnProofread", "btnRewrite", "btnTranslate")
ACTION_GRID = (("btnSummarize", "btnExplain"), ("btnAnalyze", "btnProofread"), ("btnRewrite", "btnTranslate"))


def _sel_block_height():
    rows = len(ACTION_GRID)
    return SEL_LABEL_H + GAP + SEL_PREVIEW_H + GAP + rows * BTN_H + (rows - 1) * GAP + PAD


def layout(container, width, height, sel_visible=False):
    """Đặt lại vị trí các control bên trong `container` (XControlContainer)."""
    w = max(width - 2 * PAD, 80)
    half = (w - GAP) // 2
    y = PAD

    def put(name, x, yy, ww, hh):
        container.getControl(name).setPosSize(x, yy, ww, hh, POSSIZE)

    put("btnNewChat", PAD, y, half, BTN_H)
    put("btnSettings", PAD + half + GAP, y, half, BTN_H)
    y += BTN_H + PAD

    bottom = (BTN_H + PAD                                   # hàng Copy | Chèn | Thay thế
              + BTN_H + PAD                                 # nút Đọc văn bản đã chọn
              + (_sel_block_height() if sel_visible else 0)
              + STATUS_H + GAP + INPUT_H + GAP + BTN_H + PAD)
    history_h = max(height - y - bottom, MIN_HISTORY_H)
    put("txtHistory", PAD, y, w, history_h)
    y += history_h + GAP

    third = (w - 2 * GAP) // 3
    put("btnCopy", PAD, y, third, BTN_H)
    put("btnInsert", PAD + third + GAP, y, third, BTN_H)
    put("btnReplace", PAD + 2 * (third + GAP), y, w - 2 * (third + GAP), BTN_H)
    y += BTN_H + PAD

    put("btnReadSel", PAD, y, w, BTN_H)
    y += BTN_H + PAD

    for name in SEL_CONTROLS:
        container.getControl(name).setVisible(sel_visible)
    if sel_visible:
        clear_w = 50
        put("lblSel", PAD, y + 3, w - clear_w - GAP, SEL_LABEL_H - 3)
        put("btnClearSel", PAD + w - clear_w, y, clear_w, SEL_LABEL_H)
        y += SEL_LABEL_H + GAP
        put("txtSel", PAD, y, w, SEL_PREVIEW_H)
        y += SEL_PREVIEW_H + GAP
        for i, (left, right) in enumerate(ACTION_GRID):
            put(left, PAD, y, half, BTN_H)
            put(right, PAD + half + GAP, y, half, BTN_H)
            y += BTN_H + (GAP if i < len(ACTION_GRID) - 1 else PAD)

    put("lblStatus", PAD, y, w, STATUS_H)
    y += STATUS_H + GAP
    put("txtInput", PAD, y, w, INPUT_H)
    y += INPUT_H + GAP
    send_w = min(110, w)
    put("btnSend", PAD + w - send_w, y, send_w, BTN_H)
    y += BTN_H + PAD
    return y  # tổng chiều cao tối thiểu cần dùng
