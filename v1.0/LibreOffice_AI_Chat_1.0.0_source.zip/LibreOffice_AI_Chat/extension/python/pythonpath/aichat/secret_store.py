# -*- coding: utf-8 -*-
"""Lưu API key an toàn.

Windows : Windows Credential Manager (advapi32 CredWriteW/CredReadW/CredDeleteW qua ctypes).
          Key được Windows mã hóa theo tài khoản người dùng; xem/xóa được trong
          Control Panel > Credential Manager > Windows Credentials > "LibreOffice AI Chat/Gemini".
Khác    : kho mật khẩu của LibreOffice (com.sun.star.task.PasswordContainer).

Không bao giờ ghi key ra log, file cấu hình hay mã nguồn.
"""
import sys

TARGET = "LibreOffice AI Chat/Gemini"
_PC_URL = "vnd.aichat.writer://gemini"
_PC_USER = "api-key"


class WindowsCredentialStore(object):
    name = "Windows Credential Manager"

    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self._ct = ctypes

        class FILETIME(ctypes.Structure):
            _fields_ = [("dwLowDateTime", wintypes.DWORD), ("dwHighDateTime", wintypes.DWORD)]

        class CREDENTIAL(ctypes.Structure):
            _fields_ = [("Flags", wintypes.DWORD),
                        ("Type", wintypes.DWORD),
                        ("TargetName", wintypes.LPWSTR),
                        ("Comment", wintypes.LPWSTR),
                        ("LastWritten", FILETIME),
                        ("CredentialBlobSize", wintypes.DWORD),
                        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
                        ("Persist", wintypes.DWORD),
                        ("AttributeCount", wintypes.DWORD),
                        ("Attributes", ctypes.c_void_p),
                        ("TargetAlias", wintypes.LPWSTR),
                        ("UserName", wintypes.LPWSTR)]

        self.CREDENTIAL = CREDENTIAL
        PCRED = ctypes.POINTER(CREDENTIAL)
        adv = ctypes.WinDLL("advapi32", use_last_error=True)
        self._write = adv.CredWriteW
        self._write.argtypes = [PCRED, wintypes.DWORD]
        self._write.restype = wintypes.BOOL
        self._read = adv.CredReadW
        self._read.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(PCRED)]
        self._read.restype = wintypes.BOOL
        self._delete = adv.CredDeleteW
        self._delete.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD]
        self._delete.restype = wintypes.BOOL
        self._free = adv.CredFree
        self._free.argtypes = [ctypes.c_void_p]
        self._free.restype = None
        self.PCRED = PCRED

    CRED_TYPE_GENERIC = 1
    CRED_PERSIST_LOCAL_MACHINE = 2
    ERROR_NOT_FOUND = 1168

    def save(self, key):
        ct = self._ct
        blob = key.encode("utf-8")
        buf = (ct.c_ubyte * len(blob)).from_buffer_copy(blob)
        cred = self.CREDENTIAL()
        cred.Type = self.CRED_TYPE_GENERIC
        cred.TargetName = TARGET
        cred.Comment = "API key Gemini cho extension AI Chat của LibreOffice Writer"
        cred.CredentialBlobSize = len(blob)
        cred.CredentialBlob = ct.cast(buf, ct.POINTER(ct.c_ubyte))
        cred.Persist = self.CRED_PERSIST_LOCAL_MACHINE
        cred.UserName = "gemini-api-key"
        if not self._write(ct.byref(cred), 0):
            raise OSError("CredWriteW lỗi %d" % ct.get_last_error())
        return None

    def load(self):
        ct = self._ct
        pcred = self.PCRED()
        if not self._read(TARGET, self.CRED_TYPE_GENERIC, 0, ct.byref(pcred)):
            if ct.get_last_error() == self.ERROR_NOT_FOUND:
                return ""
            raise OSError("CredReadW lỗi %d" % ct.get_last_error())
        try:
            c = pcred.contents
            return ct.string_at(c.CredentialBlob, c.CredentialBlobSize).decode("utf-8")
        finally:
            self._free(pcred)

    def delete(self):
        ct = self._ct
        if not self._delete(TARGET, self.CRED_TYPE_GENERIC, 0):
            if ct.get_last_error() != self.ERROR_NOT_FOUND:
                raise OSError("CredDeleteW lỗi %d" % ct.get_last_error())


class LibreOfficePasswordStore(object):
    name = "kho mật khẩu LibreOffice"

    def __init__(self, ctx):
        smgr = ctx.ServiceManager
        self._pc = smgr.createInstanceWithContext("com.sun.star.task.PasswordContainer", ctx)
        self._handler = smgr.createInstanceWithContext("com.sun.star.task.InteractionHandler", ctx)

    def save(self, key):
        """Trả về None nếu lưu lâu dài, hoặc một ghi chú nếu chỉ lưu tạm trong phiên."""
        try:
            self._pc.addPersistent(_PC_URL, _PC_USER, (key,), self._handler)
            return None
        except Exception:
            # NoMasterException: người dùng chưa bật "lưu mật khẩu vĩnh viễn" trong LibreOffice.
            # Không tự ý đổi thiết lập bảo mật của họ -> chỉ lưu trong bộ nhớ của phiên này.
            self._pc.add(_PC_URL, _PC_USER, (key,), self._handler)
            return ("Key chỉ được giữ tạm đến khi đóng LibreOffice. Để lưu lâu dài: Công cụ > Tùy chọn > "
                    "LibreOffice > Bảo mật > bật 'Lưu vĩnh viễn mật khẩu cho kết nối web'.")

    def load(self):
        rec = self._pc.findForName(_PC_URL, _PC_USER, self._handler)
        for u in (rec.UserList or ()):
            if u.UserName == _PC_USER and u.Passwords:
                return u.Passwords[0]
        return ""

    def delete(self):
        for fn in (self._pc.removePersistent, self._pc.remove):
            try:
                fn(_PC_URL, _PC_USER)
            except Exception:
                pass


_store = None


def get_store(ctx):
    global _store
    if _store is None:
        if sys.platform.startswith("win"):
            try:
                _store = WindowsCredentialStore()
            except Exception:
                _store = LibreOfficePasswordStore(ctx)
        else:
            _store = LibreOfficePasswordStore(ctx)
    return _store
