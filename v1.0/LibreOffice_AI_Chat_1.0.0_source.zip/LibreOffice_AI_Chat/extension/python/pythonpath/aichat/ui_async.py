# -*- coding: utf-8 -*-
"""Chạy việc ở luồng nền và đưa kết quả về luồng giao diện (main thread) một cách an toàn.

Luồng nền KHÔNG được chạm vào control UNO. Mọi cập nhật giao diện đi qua
com.sun.star.awt.AsyncCallback -> được LibreOffice thực thi trên main thread.
"""
import threading
import traceback

import unohelper
from com.sun.star.awt import XCallback


class _Callback(unohelper.Base, XCallback):
    def __init__(self, fn, on_error):
        self._fn = fn
        self._on_error = on_error

    def notify(self, data):
        try:
            self._fn()
        except Exception:
            self._on_error(traceback.format_exc())


class MainThread(object):
    def __init__(self, ctx, log):
        self._async = ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.AsyncCallback", ctx)
        self._log = log

    def post(self, fn):
        """Gọi được từ bất kỳ luồng nào; fn() sẽ chạy trên main thread."""
        self._async.addCallback(_Callback(fn, self._log), None)


def run_in_background(target, name="aichat-worker"):
    t = threading.Thread(target=target, name=name)
    t.daemon = True
    t.start()
    return t
