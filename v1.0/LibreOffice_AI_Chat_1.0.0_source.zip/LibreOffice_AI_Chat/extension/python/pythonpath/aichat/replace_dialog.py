# -*- coding: utf-8 -*-
"""Hộp thoại xác nhận thay thế: hiển thị nội dung trước / sau. Mặc định chọn Hủy."""


def confirm_replace(ctx, parent_window, before, after):
    """Trả về True chỉ khi người dùng bấm 'Xác nhận thay thế'."""
    smgr = ctx.ServiceManager
    dm = smgr.createInstanceWithContext("com.sun.star.awt.UnoControlDialogModel", ctx)
    dm.Width, dm.Height = 320, 268
    dm.Title = "Xác nhận thay thế đoạn văn"
    W = 308

    def add(kind, name, x, y, w, h, **props):
        m = dm.createInstance("com.sun.star.awt.UnoControl%sModel" % kind)
        m.PositionX, m.PositionY, m.Width, m.Height = x, y, w, h
        for k, v in props.items():
            setattr(m, k, v)
        dm.insertByName(name, m)

    add("FixedText", "lblBefore", 6, 6, W, 10, Label="Nội dung TRƯỚC khi thay thế (văn bản gốc trong tài liệu):")
    add("Edit", "txtBefore", 6, 17, W, 88, MultiLine=True, ReadOnly=True, VScroll=True, Text=before)
    add("FixedText", "lblAfter", 6, 110, W, 10, Label="Nội dung SAU khi thay thế (kết quả AI; định dạng sẽ được áp dụng):")
    add("Edit", "txtAfter", 6, 121, W, 100, MultiLine=True, ReadOnly=True, VScroll=True, Text=after)
    add("FixedText", "lblNote", 6, 226, W, 18, MultiLine=True,
        Label="Có thể hoàn tác toàn bộ bằng MỘT lần Ctrl+Z (Sửa > Hoàn tác).")
    add("Button", "btnCancel", 156, 248, 60, 14, Label="Hủy", PushButtonType=2, DefaultButton=True)   # CANCEL
    add("Button", "btnOK", 220, 248, 94, 14, Label="Xác nhận thay thế", PushButtonType=1)           # OK

    dlg = smgr.createInstanceWithContext("com.sun.star.awt.UnoControlDialog", ctx)
    dlg.setModel(dm)
    toolkit = smgr.createInstanceWithContext("com.sun.star.awt.Toolkit", ctx)
    dlg.createPeer(toolkit, parent_window)
    try:
        dlg.getControl("btnCancel").setFocus()
        return dlg.execute() == 1   # 1 = OK
    finally:
        dlg.dispose()
