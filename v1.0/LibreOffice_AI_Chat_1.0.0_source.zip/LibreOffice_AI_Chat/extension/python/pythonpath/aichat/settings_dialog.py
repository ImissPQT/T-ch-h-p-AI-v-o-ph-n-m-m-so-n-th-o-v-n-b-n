# -*- coding: utf-8 -*-
"""Hộp thoại Cài đặt: API key (lưu / kiểm tra / xóa), chọn mô hình, system prompt."""
import traceback

import unohelper
from com.sun.star.awt import XActionListener

from aichat import gemini_client, settings
from aichat.gemini_client import GeminiError, SUGGESTED_MODELS
from aichat.secret_store import get_store
from aichat.ui_async import run_in_background

PRIVACY_NOTICE = (
    "Tin nhắn bạn gửi được chuyển tới Google Gemini API qua Internet và áp dụng chính sách dữ liệu của Google. "
    "Với Free Tier, Google có thể dùng nội dung để cải thiện sản phẩm. Không gửi thông tin nhạy cảm. "
    "Extension không tự gửi nội dung tài liệu."
)
KEY_URL = "https://aistudio.google.com/apikey"


class _Listener(unohelper.Base, XActionListener):
    def __init__(self, fn, log):
        self._fn, self._log = fn, log

    def actionPerformed(self, ev):
        try:
            self._fn()
        except Exception:
            self._log(traceback.format_exc())

    def disposing(self, ev):
        pass


class SettingsDialog(object):
    def __init__(self, ctx, main_thread, log, parent_window=None):
        self.ctx, self.main, self.log = ctx, main_thread, log
        self.parent = parent_window
        self.store = get_store(ctx)
        self.cfg = settings.load(ctx)
        self.closed = False
        self.busy = False
        self._listeners = []
        self._build()

    # ------------------------------------------------------------ dựng giao diện
    def _add(self, kind, name, x, y, w, h, **props):
        m = self.dm.createInstance("com.sun.star.awt.UnoControl%sModel" % kind)
        m.PositionX, m.PositionY, m.Width, m.Height = x, y, w, h
        for k, v in props.items():
            setattr(m, k, v)
        self.dm.insertByName(name, m)
        return m

    def _build(self):
        smgr = self.ctx.ServiceManager
        dm = self.dm = smgr.createInstanceWithContext("com.sun.star.awt.UnoControlDialogModel", self.ctx)
        dm.Width, dm.Height = 290, 272
        dm.Title = "Cài đặt AI Chat – Google Gemini"
        W = 278
        self._add("FixedText", "lblNotice", 6, 6, W, 34, MultiLine=True, Label=PRIVACY_NOTICE)
        self._add("FixedText", "lblKey", 6, 44, W, 10, Label="API Key Gemini (dán key mới để thay key cũ):")
        self._add("Edit", "edtKey", 6, 55, W, 13, EchoChar=ord("*"))
        self._add("Button", "btnSaveKey", 6, 72, 64, 14, Label="Lưu key")
        self._add("Button", "btnTest", 74, 72, 90, 14, Label="Kiểm tra kết nối")
        self._add("Button", "btnDeleteKey", 168, 72, 64, 14, Label="Xóa key")
        self._add("FixedText", "lblKeyState", 6, 90, W, 10, Label="")
        self._add("FixedHyperlink", "lnkKey", 6, 102, W, 10,
                  Label="Tạo API key miễn phí: " + KEY_URL.replace("https://", ""), URL=KEY_URL)
        self._add("FixedText", "lblModel", 6, 118, W, 10, Label="Mô hình (có thể gõ tên khác):")
        self._add("ComboBox", "cmbModel", 6, 129, 196, 13, Dropdown=True, LineCount=12)
        self._add("Button", "btnRefresh", 206, 129, 78, 13, Label="Tải danh sách")
        self._add("FixedText", "lblModelNote", 6, 145, W, 10,
                  Label="Flash / Flash-Lite có Free Tier (kiểm tra tại ai.google.dev/pricing).")
        self._add("FixedText", "lblPrompt", 6, 159, 200, 10, Label="System prompt (hướng dẫn chung cho AI):")
        self._add("Button", "btnResetPrompt", 206, 157, 78, 12, Label="Mặc định")
        self._add("Edit", "edtPrompt", 6, 171, W, 36, MultiLine=True, VScroll=True, AutoVScroll=True)
        self._add("FixedText", "lblStatus", 6, 210, W, 40, MultiLine=True, Label="")
        self._add("Button", "btnOK", 150, 252, 70, 14, Label="Lưu và đóng", DefaultButton=True)
        self._add("Button", "btnClose", 224, 252, 60, 14, Label="Hủy", PushButtonType=2)  # CANCEL

        self.dlg = smgr.createInstanceWithContext("com.sun.star.awt.UnoControlDialog", self.ctx)
        self.dlg.setModel(dm)
        toolkit = smgr.createInstanceWithContext("com.sun.star.awt.Toolkit", self.ctx)
        self.dlg.createPeer(toolkit, self.parent)

        models = list(SUGGESTED_MODELS)
        for m in self.cfg.get("known_models", []):
            if m not in models:
                models.append(m)
        self._set_models(models)
        self.m("cmbModel").Text = self.cfg["model"]
        self.m("edtPrompt").Text = self.cfg["system_prompt"]

        for name, fn in (("btnSaveKey", self.on_save_key), ("btnTest", self.on_test),
                         ("btnDeleteKey", self.on_delete_key), ("btnRefresh", self.on_refresh),
                         ("btnResetPrompt", self.on_reset_prompt), ("btnOK", self.on_ok)):
            lst = _Listener(fn, self.log)
            self._listeners.append(lst)
            self.dlg.getControl(name).addActionListener(lst)
        self._refresh_key_state()

    def m(self, name):
        return self.dm.getByName(name)

    def _set_models(self, models):
        self.m("cmbModel").StringItemList = tuple(models)

    def _status(self, text):
        if not self.closed:
            self.m("lblStatus").Label = text

    def _set_busy(self, busy):
        self.busy = busy
        for n in ("btnSaveKey", "btnTest", "btnDeleteKey", "btnRefresh"):
            self.m(n).Enabled = not busy

    def _stored_key(self):
        try:
            return self.store.load()
        except Exception:
            self.log("secret_store.load: " + traceback.format_exc().splitlines()[-1])
            return ""

    def _refresh_key_state(self):
        has = bool(self._stored_key())
        self.m("lblKeyState").Label = (
            ("Trạng thái: ĐÃ LƯU API key trong %s." if has else "Trạng thái: CHƯA có API key (lưu tại %s khi bấm Lưu key).")
            % self.store.name)

    # ------------------------------------------------------------ sự kiện
    def _typed_key(self):
        return (self.m("edtKey").Text or "").strip()

    def on_save_key(self, quiet=False):
        key = self._typed_key()
        if not key:
            self._status("Hãy dán API key vào ô trước khi bấm Lưu key.")
            return False
        if any(c.isspace() for c in key) or len(key) < 20:
            self._status("API key có vẻ không đúng định dạng (quá ngắn hoặc chứa khoảng trắng).")
            return False
        try:
            note = self.store.save(key)
        except Exception:
            self.log("secret_store.save: " + traceback.format_exc().splitlines()[-1])
            self._status("Không lưu được API key vào %s." % self.store.name)
            return False
        self.m("edtKey").Text = ""
        self._refresh_key_state()
        if note:
            self._status("Đã lưu API key. " + note)
        elif not quiet:
            self._status("Đã lưu API key vào %s. Bấm 'Kiểm tra kết nối' để thử." % self.store.name)
        return True

    def on_delete_key(self):
        if not self._stored_key():
            self._status("Không có API key nào đang được lưu.")
            return
        toolkit = self.ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.Toolkit", self.ctx)
        box = toolkit.createMessageBox(self.dlg.getPeer(), 2, 3, "Xóa API key",  # QUERYBOX, YES_NO
                                       "Xóa API key Gemini đã lưu khỏi %s?" % self.store.name)
        if box.execute() != 2:  # 2 = YES
            return
        try:
            self.store.delete()
            self._status("Đã xóa API key.")
        except Exception:
            self.log("secret_store.delete: " + traceback.format_exc().splitlines()[-1])
            self._status("Không xóa được API key.")
        self._refresh_key_state()

    def _key_for_test(self):
        typed = self._typed_key()
        return typed, (typed or self._stored_key())

    def on_test(self):
        if self.busy:
            return
        typed, key = self._key_for_test()
        if not key:
            self._status("Chưa có API key. Dán key vào ô rồi bấm Kiểm tra kết nối.")
            return
        model = (self.m("cmbModel").Text or "").strip() or gemini_client.DEFAULT_MODEL
        self._set_busy(True)
        self._status("Bước 1/2: đang kiểm tra Internet và API key...")

        def stage1(n, models):
            self.main.post(lambda: self._status(
                "✔ Bước 1/2: Internet và API key hợp lệ (%d mô hình).\n"
                "Bước 2/2: đang hỏi thử mô hình %s (có thể mất tới 60 giây)..." % (len(models), model)))

        def work():
            try:
                models, reply, secs = gemini_client.test_connection(key, model, stage1)
                self.main.post(lambda: self._test_done(models, model, reply, secs, typed))
            except gemini_client.StageError as e:
                self.log("test_connection: buoc %d %s (HTTP %s)" % (e.stage, e.kind, e.status))
                if e.stage == 1:
                    msg = "✖ Bước 1 (Internet/API key) thất bại: " + e.message
                else:
                    msg = ("✔ Internet và API key đều ổn.\n✖ Bước 2: mô hình %s chưa trả lời được: %s"
                           % (model, e.message))
                self.main.post(lambda: self._test_failed(msg))
            except GeminiError as e:
                self.log("test_connection: %s (HTTP %s)" % (e.kind, e.status))
                msg = "✖ " + e.message
                self.main.post(lambda: self._test_failed(msg))
            except Exception:
                self.log("test_connection: " + traceback.format_exc())
                self.main.post(lambda: self._test_failed("✖ Lỗi không xác định khi kiểm tra kết nối."))
        run_in_background(work, "aichat-test")

    def _test_done(self, models, model, reply, secs, typed):
        if self.closed:
            return
        self._set_busy(False)
        self._merge_models(models)
        msg = "✔ Kết nối thành công. Mô hình %s trả lời \"%s\" sau %.1f giây." % (
            model, (reply or "(trống)")[:40], secs)
        if typed:
            msg += " Key vừa nhập CHƯA được lưu – bấm Lưu key hoặc Lưu và đóng."
        self._status(msg)

    def _test_failed(self, msg):
        if self.closed:
            return
        self._set_busy(False)
        self._status(msg)

    def on_refresh(self):
        if self.busy:
            return
        typed, key = self._key_for_test()
        if not key:
            self._status("Cần API key để tải danh sách mô hình.")
            return
        self._set_busy(True)
        self._status("Đang tải danh sách mô hình...")

        def work():
            try:
                models = gemini_client.GeminiClient(key, timeout=30).list_models()
                self.main.post(lambda: self._refresh_done(models))
            except GeminiError as e:
                self.log("list_models: %s (HTTP %s)" % (e.kind, e.status))
                msg = e.message
                self.main.post(lambda: self._test_failed("✖ " + msg))
            except Exception:
                self.log("list_models: " + traceback.format_exc())
                self.main.post(lambda: self._test_failed("Lỗi không xác định."))
        run_in_background(work, "aichat-models")

    def _refresh_done(self, models):
        if self.closed:
            return
        self._set_busy(False)
        self._merge_models(models)
        self._status("Đã tải %d mô hình hỗ trợ chat. Nên chọn loại Flash/Flash-Lite để dùng Free Tier." % len(models))

    def _merge_models(self, models):
        if not models:
            return
        self.cfg["known_models"] = list(models)
        merged = [m for m in SUGGESTED_MODELS if m in models or m == "gemini-flash-latest"]
        merged += [m for m in models if m not in merged]
        current = self.m("cmbModel").Text
        self._set_models(merged)
        self.m("cmbModel").Text = current

    def on_reset_prompt(self):
        self.m("edtPrompt").Text = settings.DEFAULT_SYSTEM_PROMPT

    def on_ok(self):
        if self._typed_key() and not self.on_save_key(quiet=True):
            return  # key nhập sai định dạng -> giữ hộp thoại để sửa
        self.cfg["model"] = (self.m("cmbModel").Text or "").strip() or gemini_client.DEFAULT_MODEL
        self.cfg["system_prompt"] = (self.m("edtPrompt").Text or "").strip() or settings.DEFAULT_SYSTEM_PROMPT
        try:
            settings.save(self.ctx, self.cfg)
        except Exception:
            self.log("settings.save: " + traceback.format_exc())
            self._status("Không ghi được file cài đặt.")
            return
        self.dlg.endExecute()

    def execute(self):
        try:
            self.dlg.execute()
        finally:
            self.closed = True
            self.dlg.dispose()
