# -*- coding: utf-8 -*-
"""Đọc nội dung người dùng đang bôi đen trong Writer qua UNO API.

CHỈ ĐỌC: module này không gọi bất kỳ hàm nào làm thay đổi tài liệu
(không setString, không insert, không dispatch lệnh sửa) => định dạng gốc giữ nguyên.
Không bao giờ đọc toàn bộ tài liệu.
"""


class SelectionError(Exception):
    def __init__(self, message):
        Exception.__init__(self, message)
        self.message = message


class Snapshot(object):
    """Bản chụp vùng chọn tại thời điểm bấm 'Đọc văn bản đã chọn'. Đây chính là nội dung sẽ gửi."""

    def __init__(self, text, kind, parts=1, anchor=None, doc=None):
        self.text = text
        # Neo vùng gốc (Giai đoạn 6): TextCursor do Writer tự cập nhật vị trí khi tài liệu bị sửa
        # ở chỗ khác. Chỉ có khi vùng chọn là MỘT đoạn liền mạch (kind == "text").
        self.anchor = anchor
        self.doc = doc
        self.kind = kind          # "text" | "multi" | "table"
        self.parts = parts        # số vùng chọn (Ctrl+kéo chuột có thể chọn nhiều vùng)
        self.chars = len(text)
        self.words = len(text.split())
        self.paragraphs = len([p for p in text.split("\n") if p.strip() and p.strip() != "[\u2026]"])

    def locate_for_replace(self, frame):
        """Xác định lại vùng gốc để thay thế. Trả về (doc, anchor) hoặc ném SelectionError.

        Không tìm kiếm/đoán vị trí mới: chỉ dùng neo đã lưu và so khớp nguyên văn.
        """
        if self.kind != "text" or self.anchor is None:
            raise SelectionError("Chỉ thay thế được khi đoạn đã đọc là một vùng chữ liền mạch "
                                 "(không áp dụng cho nhiều vùng hoặc ô bảng). Hãy dùng 'Chèn'.")
        try:
            current_doc = frame.getController().getModel()
            same_doc = current_doc is not None and current_doc.RuntimeUID == self.doc.RuntimeUID
            now = _norm(self.anchor.getString())
        except Exception:
            raise SelectionError("Tài liệu chứa đoạn văn gốc đã đóng hoặc không còn truy cập được.")
        if not same_doc:
            raise SelectionError("Cửa sổ này đang mở tài liệu khác với tài liệu chứa đoạn văn gốc.")
        if not now:
            raise SelectionError("Đoạn văn gốc đã bị xóa khỏi tài liệu. Không thay thế để tránh ghi sai chỗ.")
        if now != self.text:
            raise SelectionError("Đoạn văn gốc đã bị sửa sau khi gửi cho AI. Không thay thế để tránh ghi đè "
                                 "nội dung mới. Hãy đọc lại vùng chọn và gửi lại.")
        return current_doc, self.anchor

    def summary(self):
        s = "%d đoạn · %d ký tự" % (self.paragraphs, self.chars)
        if self.kind == "multi":
            s += " · %d vùng" % self.parts
        elif self.kind == "table":
            s += " · bảng"
        return s


def _norm(s):
    return (s or "").replace("\r\n", "\n").replace("\r", "\n").replace(" ", "\n").replace(" ", "\n")


def _supports(obj, service):
    try:
        return obj.supportsService(service)
    except Exception:
        return False


def _table_text(controller, table_cursor):
    """Chọn ô trong bảng: trả về các hàng, các ô cách nhau bởi TAB."""
    table = controller.getViewCursor().TextTable
    if table is None:
        raise SelectionError("Không đọc được bảng đang chọn.")
    rng = table.getCellRangeByName(table_cursor.getRangeName())
    try:
        rows = rng.getDataArray()
    except Exception:
        raise SelectionError("Bảng có ô gộp phức tạp, chưa đọc được. Hãy bôi đen phần chữ thay vì chọn ô.")
    lines = []
    for row in rows:
        cells = []
        for v in row:
            if isinstance(v, float) and v.is_integer():
                v = int(v)
            cells.append(_norm(str(v)).replace("\n", " "))
        lines.append("\t".join(cells))
    return "\n".join(lines)


def read_selection(frame):
    """Trả về Snapshot của vùng chọn hiện tại, hoặc ném SelectionError với thông báo tiếng Việt."""
    controller = frame.getController() if frame is not None else None
    model = controller.getModel() if controller is not None else None
    if model is None or not _supports(model, "com.sun.star.text.TextDocument"):
        raise SelectionError("Cửa sổ hiện tại không phải tài liệu Writer.")
    sel = controller.getSelection()
    if sel is None:
        raise SelectionError("Chưa có văn bản nào được chọn. Hãy bôi đen đoạn cần dùng rồi bấm lại.")

    if _supports(sel, "com.sun.star.text.TextTableCursor"):
        text = _table_text(controller, sel)
        if not text.strip():
            raise SelectionError("Các ô bảng đang chọn không có chữ.")
        return Snapshot(text, "table")

    if _supports(sel, "com.sun.star.text.TextRanges"):
        parts = []
        for i in range(sel.getCount()):
            s = _norm(sel.getByIndex(i).getString())
            if s.strip():
                parts.append(s)
        if not parts:
            raise SelectionError("Chưa có văn bản nào được bôi đen (con trỏ chỉ đang đứng yên). "
                                 "Hãy bôi đen đoạn cần dùng rồi bấm lại.")
        if len(parts) == 1:
            rng = [sel.getByIndex(i) for i in range(sel.getCount()) if _norm(sel.getByIndex(i).getString()).strip()][0]
            anchor = rng.getText().createTextCursorByRange(rng)   # chỉ tạo con trỏ, không sửa tài liệu
            return Snapshot(parts[0], "text", 1, anchor, model)
        return Snapshot("\n\n[…]\n\n".join(parts), "multi", len(parts))

    if (_supports(sel, "com.sun.star.drawing.ShapeCollection") or _supports(sel, "com.sun.star.text.TextFrame")
            or _supports(sel, "com.sun.star.text.TextGraphicObject")
            or _supports(sel, "com.sun.star.text.TextEmbeddedObject")):
        raise SelectionError("Bạn đang chọn hình ảnh/khung/đối tượng, không phải văn bản. "
                             "Hãy bôi đen phần chữ rồi bấm lại.")
    raise SelectionError("Loại vùng chọn này chưa được hỗ trợ. Hãy bôi đen phần chữ rồi bấm lại.")


def current_text_or_none(frame):
    """Dùng để phát hiện vùng chọn đã thay đổi sau khi đọc (không ném lỗi)."""
    try:
        return read_selection(frame).text
    except Exception:
        return None
