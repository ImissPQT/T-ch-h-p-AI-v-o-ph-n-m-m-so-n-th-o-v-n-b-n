# -*- coding: utf-8 -*-
"""Component UNO: factory tạo AI Chat Panel trong Sidebar của LibreOffice Writer.

Luồng hoạt động:
  Sidebar.xcu  -> ImplementationURL private:resource/toolpanel/AIChatPanelFactory/AIChatPanel
  Factories.xcu -> ánh xạ "AIChatPanelFactory" tới implementation vn.aichat.writer.PanelFactory
  PanelFactory.createUIElement() -> ChatPanel (XUIElement + XToolPanel + XSidebarPanel)

Giai đoạn 3-4: nút Gửi gọi Google Gemini API (HTTPS, streaming) ở luồng nền;
kết quả đưa về giao diện qua AsyncCallback để Writer không bị treo.
Giai đoạn 5: đọc văn bản đang bôi đen (chỉ đọc), cho xem trước, chỉ gửi khi người dùng bấm thao tác.
Giai đoạn 6: Copy / Chèn (Markdown -> định dạng Writer) / Thay thế an toàn (xác nhận + 1 bước Undo)
cho câu trả lời AI mới nhất.
"""
import os
import sys
import tempfile
import threading
import time
import traceback

import uno
import unohelper
from com.sun.star.awt import XActionListener, XWindowListener, XKeyListener
from com.sun.star.lang import XComponent
from com.sun.star.ui import XUIElement, XToolPanel, XSidebarPanel, XUIElementFactory, LayoutSize

from aichat import EXTENSION_ID
from aichat.layout import layout

IMPL_NAME = "vn.aichat.writer.PanelFactory"
LOG_PATH = os.path.join(tempfile.gettempdir(), "aichat_writer.log")


def log(msg):
    """Ghi log ra %TEMP%/aichat_writer.log. KHÔNG bao giờ ghi API key hay nội dung tin nhắn."""
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg.rstrip() + "\n")
    except Exception:
        pass


# Các module dưới đây được import sau khi định nghĩa log() để lỗi import cũng được ghi lại
try:
    from aichat import settings
    from aichat.chat_session import ChatSession
    from aichat.clipboard import copy_text
    from aichat.document import SelectionError, current_text_or_none, read_selection
    from aichat.replace_dialog import confirm_replace
    from aichat.prompts import (ACTIONS, CUSTOM_STRUCTURED_RULES, STRUCTURED_ACTIONS, STRUCTURED_RULES,
                                build_message, display_structured, display_text, parse_structured,
                                partial_result, structured_config)
    from aichat.writer_insert import EditError, insert_markdown, replace_range, run_as_single_undo
    from aichat.gemini_client import GeminiClient, GeminiError
    from aichat.markdown_text import to_plain
    from aichat.secret_store import get_store
    from aichat.ui_async import MainThread, run_in_background
except Exception:
    log("Lỗi import module: " + traceback.format_exc())
    raise

INTRO = (
    "Xin chào! Hãy nhập câu hỏi rồi bấm Gửi (hoặc Ctrl+Enter).\n"
    "Muốn hỏi về một đoạn trong tài liệu: bôi đen đoạn đó → bấm 'Đọc văn bản đã chọn' → kiểm tra → chọn thao tác.\n\n"
    "Lưu ý: tin nhắn được gửi tới Google Gemini API qua Internet và áp dụng chính sách dữ liệu của Google "
    "(với Free Tier, Google có thể dùng nội dung để cải thiện sản phẩm). Extension không tự gửi nội dung tài liệu."
)
NO_KEY_HINT = "Chưa có API key Gemini. Bấm 'Cài đặt' để nhập key (tạo miễn phí tại aistudio.google.com/apikey)."


def extension_url(ctx, relative):
    pip = ctx.getValueByName("/singletons/com.sun.star.deployment.PackageInformationProvider")
    return pip.getPackageLocation(EXTENSION_ID) + "/" + relative


class _ButtonListener(unohelper.Base, XActionListener):
    def __init__(self, callback):
        self._cb = callback

    def actionPerformed(self, ev):
        try:
            self._cb()
        except Exception:
            log(traceback.format_exc())

    def disposing(self, ev):
        pass


class _ResizeListener(unohelper.Base, XWindowListener):
    def __init__(self, panel):
        self._panel = panel

    def windowResized(self, ev):
        self._panel.relayout()

    def windowMoved(self, ev): pass
    def windowShown(self, ev): pass
    def windowHidden(self, ev): pass
    def disposing(self, ev): pass


class _CtrlEnterListener(unohelper.Base, XKeyListener):
    """Ctrl+Enter trong ô nhập = Gửi (Enter thường vẫn xuống dòng)."""

    def __init__(self, panel):
        self._panel = panel

    def keyPressed(self, ev):
        RETURN = uno.getConstantByName("com.sun.star.awt.Key.RETURN")
        MOD1 = uno.getConstantByName("com.sun.star.awt.KeyModifier.MOD1")
        if ev.KeyCode == RETURN and (ev.Modifiers & MOD1):
            try:
                self._panel.on_send(from_keyboard=True)
            except Exception:
                log(traceback.format_exc())

    def keyReleased(self, ev): pass
    def disposing(self, ev): pass


class _Request(object):
    """Trạng thái của MỘT yêu cầu đang chạy. Luồng nền chỉ ghi vào đây, không chạm UI."""

    def __init__(self, session_id):
        self.session_id = session_id
        self.t0 = time.time()
        self.phase = "sending"  # sending -> waiting -> receiving
        self.cancelled = False
        self.done = threading.Event()
        self.lock = threading.Lock()
        self.chunks = []
        self.flush_pending = False


class ChatPanel(unohelper.Base, XUIElement, XToolPanel, XSidebarPanel, XComponent):
    """Một panel cho mỗi cửa sổ Writer (mỗi Frame có một Sidebar riêng)."""

    def __init__(self, ctx, frame, parent_window, resource_url):
        self.ctx = ctx
        self.Frame = frame
        self.ResourceURL = resource_url
        self.Type = uno.getConstantByName("com.sun.star.ui.UIElementType.TOOLPANEL")
        self.parent = parent_window
        self.session = ChatSession()
        self.req = None           # _Request đang chạy (None = rảnh)
        self.snapshot = None      # văn bản đã đọc từ vùng chọn, chờ người dùng xác nhận gửi
        self.disposed = False
        self.main = MainThread(ctx, log)

        provider = ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.awt.ContainerWindowProvider", ctx)
        self.Window = provider.createContainerWindow(
            extension_url(ctx, "dialogs/ChatPanel.xdl"), "", parent_window, None)
        self.Window.setVisible(True)

        self._listeners = []
        self._bind("btnSend", self.on_send)
        self._bind("btnNewChat", self.on_new_chat)
        self._bind("btnSettings", self.on_settings)
        self._bind("btnCopy", self.on_copy)
        self._bind("btnInsert", self.on_insert)
        self._bind("btnReplace", self.on_replace)
        self._bind("btnReadSel", self.on_read_selection)
        self._bind("btnClearSel", self.on_clear_selection)
        for btn, action in (("btnSummarize", "summarize"), ("btnExplain", "explain"), ("btnAnalyze", "analyze"),
                            ("btnProofread", "proofread"), ("btnRewrite", "rewrite"), ("btnTranslate", "translate")):
            self._bind(btn, (lambda a: (lambda: self.on_action(a)))(action))
        self._key_listener = _CtrlEnterListener(self)
        self.ctl("txtInput").addKeyListener(self._key_listener)

        self._resize = _ResizeListener(self)
        parent_window.addWindowListener(self._resize)
        self.relayout()
        self.render_history()
        self.set_status("Sẵn sàng" if self._has_key() else "Chưa có API key – bấm Cài đặt")

    # ---------- tiện ích ----------
    def ctl(self, name):
        return self.Window.getControl(name)

    def _bind(self, name, cb):
        lst = _ButtonListener(cb)
        self._listeners.append(lst)
        self.ctl(name).addActionListener(lst)

    def set_status(self, text):
        if not self.disposed:
            self.ctl("lblStatus").getModel().Label = text

    def relayout(self):
        size = self.parent.getPosSize()
        self.Window.setPosSize(0, 0, size.Width, size.Height, 15)
        layout(self.Window, size.Width, size.Height, self.snapshot is not None)
        if size.Width > 0 and size.Height > 0:
            self._scroll_to_end()  # vị trí cuộn tính lúc panel còn 0x0 sẽ bị lệch -> tính lại

    def _load_key(self):
        try:
            return get_store(self.ctx).load()
        except Exception:
            log("secret_store.load: " + traceback.format_exc().splitlines()[-1])
            return ""

    def _has_key(self):
        return bool(self._load_key())

    def render_history(self):
        if self.disposed:
            return
        blocks = []
        for it in self.session.items:
            if it["role"] == "user":
                blocks.append("▶ Bạn\n" + (it.get("display") or it["text"]))
            elif it["role"] == "model":
                body = to_plain(it["text"]) if it["text"] else "…"
                blocks.append("◆ Gemini\n" + body)
            else:
                blocks.append(it["text"])
        if not blocks:
            blocks.append(INTRO + ("" if self._has_key() else "\n\n" + NO_KEY_HINT))
        edit = self.ctl("txtHistory")
        text = "\n\n".join(blocks)
        edit.getModel().Text = text
        self._scroll_to_end()
        self._update_answer_buttons()

    def _scroll_to_end(self):
        edit = self.ctl("txtHistory")
        n = len(edit.getModel().Text or "")
        Sel = "com.sun.star.awt.Selection"
        edit.setSelection(uno.createUnoStruct(Sel, 0, 0))
        edit.setSelection(uno.createUnoStruct(Sel, n, n))  # cuộn xuống tin nhắn mới nhất

    def _set_busy(self, busy):
        self.ctl("btnSend").getModel().Label = "Dừng" if busy else "Gửi"
        self._update_answer_buttons()

    # ---------- Giai đoạn 6: câu trả lời mới nhất -> tài liệu ----------
    def _latest_answer(self):
        """Câu trả lời AI hoàn chỉnh mới nhất của phiên (bỏ qua câu đang nhận dở)."""
        pending = self.req.model_item if self.req is not None else None
        for it in reversed(self.session.items):
            if it["role"] == "model" and it is not pending and it["text"]:
                return it
        return None

    def _update_answer_buttons(self):
        if self.disposed:
            return
        it = None if self.req is not None else self._latest_answer()
        can_insert = bool(it and it.get("insert_text"))
        src = it.get("source") if it else None
        self.ctl("btnCopy").getModel().Enabled = bool(it)
        self.ctl("btnInsert").getModel().Enabled = can_insert
        self.ctl("btnReplace").getModel().Enabled = bool(
            can_insert and src is not None and src.kind == "text" and not it.get("replaced"))

    def _answer_or_status(self):
        if self.req is not None:
            self.set_status("Đang chờ câu trả lời – hãy đợi hoặc bấm Dừng")
            return None
        it = self._latest_answer()
        if it is None:
            self.set_status("Chưa có câu trả lời AI nào")
        return it

    def _parent_window(self):
        try:
            return self.Frame.getContainerWindow()
        except Exception:
            return None

    def on_copy(self):
        it = self._answer_or_status()
        if it is None:
            return
        text = it.get("insert_text") or it["text"]   # Viết lại/Dịch: chỉ phần kết quả
        try:
            copy_text(self.ctx, text)
        except Exception:
            log("clipboard: " + traceback.format_exc().splitlines()[-1])
            self.set_status("✖ Không sao chép được vào Clipboard")
            return
        self.set_status("✔ Đã sao chép %d ký tự vào Clipboard" % len(text))

    def on_insert(self):
        it = self._answer_or_status()
        if it is None:
            return
        if not it.get("insert_text"):
            self.set_status("Câu trả lời này không có nội dung tách riêng để chèn")
            return
        try:
            controller = self.Frame.getController()
            doc = controller.getModel()
            vc = controller.getViewCursor()
            pos = vc.getEnd()   # đang bôi đen thì chèn NGAY SAU vùng bôi đen, không xóa gì
            pos.getText()
        except Exception:
            self.set_status("✖ Không xác định được vị trí con trỏ – hãy bấm vào một chỗ trong văn bản")
            return
        try:
            end = run_as_single_undo(doc, "AI Chat: Chèn nội dung",
                                     lambda: insert_markdown(doc, pos, it["insert_text"]))
        except EditError as e:
            self.set_status("✖ " + e.message)
            return
        try:
            vc.gotoRange(end.getEnd(), False)
        except Exception:
            pass
        self.set_status("✔ Đã chèn vào tài liệu (Ctrl+Z để hoàn tác)")

    def on_replace(self):
        it = self._answer_or_status()
        if it is None:
            return
        src = it.get("source")
        if not it.get("insert_text") or src is None:
            self.set_status("Câu trả lời mới nhất không gắn với đoạn văn nào đã đọc")
            self.session.add("note", "ℹ Chỉ thay thế được câu trả lời của thao tác trên 'văn bản đã chọn' "
                                     "(Đọc văn bản đã chọn → chọn thao tác).")
            self.render_history()
            return
        if it.get("replaced"):
            self.set_status("Câu trả lời này đã được dùng để thay thế rồi")
            return
        try:
            src.locate_for_replace(self.Frame)            # kiểm tra lần 1: trước khi hỏi
        except SelectionError as e:
            self.session.add("note", "⚠ Không thay thế: " + e.message)
            self.render_history()
            self.set_status("Không thay thế – văn bản gốc đã thay đổi")
            return
        after = to_plain(it["insert_text"])
        if not confirm_replace(self.ctx, self._parent_window(), src.text, after):
            self.set_status("Đã hủy – tài liệu giữ nguyên")
            return
        try:
            doc, anchor = src.locate_for_replace(self.Frame)  # kiểm tra lần 2: ngay trước khi ghi
            run_as_single_undo(doc, "AI Chat: Thay thế đoạn văn",
                               lambda: replace_range(doc, anchor, it["insert_text"]))
        except SelectionError as e:
            self.session.add("note", "⚠ Không thay thế: " + e.message)
            self.render_history()
            self.set_status("Không thay thế – văn bản gốc đã thay đổi")
            return
        except EditError as e:
            self.set_status("✖ " + e.message)
            return
        it["replaced"] = True
        self._update_answer_buttons()
        self.set_status("✔ Đã thay thế. Nhấn Ctrl+Z một lần để hoàn tác")

    # ---------- văn bản được chọn (Giai đoạn 5) ----------
    def on_read_selection(self):
        """Chỉ ĐỌC vùng chọn và hiển thị để người dùng kiểm tra. Chưa gửi gì cho Gemini."""
        try:
            snap = read_selection(self.Frame)
        except SelectionError as e:
            self.session.add("note", "⚠ " + e.message)
            self.render_history()
            self.set_status("Chưa đọc được vùng chọn")
            return
        except Exception:
            log("read_selection: " + traceback.format_exc())
            self.set_status("Không đọc được vùng chọn (xem log)")
            return
        limit = settings.load(self.ctx)["max_message_chars"]
        if snap.chars > limit:
            self.session.add("note", "⚠ Vùng chọn quá dài (%d ký tự, tối đa %d). Hãy chọn đoạn ngắn hơn."
                             % (snap.chars, limit))
            self.render_history()
            self.set_status("Vùng chọn quá dài")
            return
        self._attach(snap)
        self.set_status("Đã đọc – CHƯA gửi. Hãy chọn thao tác")

    def _attach(self, snap):
        self.snapshot = snap
        self.ctl("lblSel").getModel().Label = snap.summary()
        self.ctl("txtSel").getModel().Text = snap.text
        self.ctl("txtSel").setSelection(uno.createUnoStruct("com.sun.star.awt.Selection", 0, 0))
        self.ctl("btnReadSel").getModel().Label = "Đọc lại vùng chọn"
        self.relayout()

    def _detach(self):
        self.snapshot = None
        self.ctl("txtSel").getModel().Text = ""
        self.ctl("btnReadSel").getModel().Label = "Đọc văn bản đã chọn"
        self.relayout()

    def on_clear_selection(self):
        self._detach()
        self.set_status("Đã bỏ văn bản đính kèm")

    def on_action(self, action):
        if self.req is not None:
            self.set_status("Đang chờ câu trả lời trước – bấm Dừng nếu muốn hủy")
            return
        if self.snapshot is None:
            self.set_status("Hãy bấm 'Đọc văn bản đã chọn' trước")
            return
        label, instruction = ACTIONS[action]
        self._send_with_selection(label, instruction, input_text=None, action=action)

    def _send_with_selection(self, label, instruction, input_text, from_keyboard=False, action=None):
        snap = self.snapshot
        # Viết lại / Dịch / yêu cầu tự nhập: yêu cầu JSON có trường result riêng (để chèn không kèm lời dẫn)
        structured = action in STRUCTURED_ACTIONS or action is None
        rules = "" if not structured else (STRUCTURED_RULES if action else CUSTOM_STRUCTURED_RULES)
        full = build_message(instruction, snap, rules)
        cfg = settings.load(self.ctx)
        if len(full) > cfg["max_message_chars"]:
            self.set_status("Nội dung quá dài (%d ký tự, tối đa %d)." % (len(full), cfg["max_message_chars"]))
            return
        if not self._load_key():
            self._no_key()
            return
        # Gửi đúng nội dung người dùng đã xem; nếu vùng chọn trong tài liệu đã đổi thì báo cho họ biết.
        changed = current_text_or_none(self.Frame) != snap.text
        self._detach()  # mỗi lần đọc chỉ gửi một lần -> tránh vô tình gửi lại tài liệu
        if changed:
            self.session.add("note", "ℹ Vùng chọn trong tài liệu đã thay đổi sau khi đọc. Đã gửi đúng nội dung "
                                     "đã đọc trước đó (bấm 'Đọc văn bản đã chọn' nếu muốn dùng vùng mới).")
        self._start_request(full, display_text(label, snap), input_text, snap, from_keyboard, structured)

    # ---------- gửi tin nhắn ----------
    def _no_key(self):
        self.session.add("note", "⚠ " + NO_KEY_HINT)
        self.render_history()
        self.set_status("Chưa có API key")

    def on_send(self, from_keyboard=False):
        if self.req is not None:
            if not from_keyboard:      # nút đang là "Dừng"
                self.cancel_request("Đã dừng theo yêu cầu.")
            return                     # chặn gửi trùng khi đang chờ
        text = (self.ctl("txtInput").getModel().Text or "").strip()
        if self.snapshot is not None:  # có văn bản đính kèm -> nội dung ô nhập là yêu cầu riêng
            if not text:
                self.set_status("Chọn một thao tác, hoặc nhập yêu cầu riêng rồi bấm Gửi")
                return
            self._send_with_selection(text, text, text, from_keyboard)
            return
        if not text:
            return
        cfg = settings.load(self.ctx)
        if len(text) > cfg["max_message_chars"]:
            self.set_status("Tin nhắn quá dài (%d ký tự, tối đa %d)." % (len(text), cfg["max_message_chars"]))
            return
        if not self._load_key():
            self._no_key()
            return
        self._start_request(text, None, text, None, from_keyboard)

    def _start_request(self, text, display, input_text, snapshot, from_keyboard=False, structured=False):
        """Gửi `text` cho Gemini (dùng chung cho chat thường và thao tác trên vùng chọn).

        display    : nội dung gọn hiển thị trong khung chat (None = hiện nguyên text)
        input_text : nội dung lấy từ ô nhập (None = không đụng ô nhập); trả lại ô nhập nếu lỗi
        snapshot   : văn bản đính kèm; được gắn lại nếu yêu cầu lỗi để người dùng thử lại
        """
        cfg = settings.load(self.ctx)
        key = self._load_key()
        session = self.session
        user_item = session.add("user", text)
        if display:
            user_item["display"] = display
        contents, trimmed = session.build_contents(cfg["history_char_budget"])
        model_item = session.add("model", "", cfg["model"])
        model_item["source"] = snapshot      # vùng gốc trong tài liệu (để Thay thế), None nếu chat thường
        if input_text is not None:
            self.ctl("txtInput").getModel().Text = ""
        if input_text is not None and from_keyboard:  # Enter của Ctrl+Enter được chèn sau sự kiện -> xóa lần nữa
            self.main.post(lambda: setattr(self.ctl("txtInput").getModel(), "Text", ""))

        req = self.req = _Request(session.id)
        req.user_item, req.model_item, req.trimmed = user_item, model_item, trimmed
        req.input_text, req.snapshot = input_text, snapshot
        req.model_name = cfg["model"]
        req.structured = structured
        self._set_busy(True)
        self.render_history()
        self.set_status("Đang gửi yêu cầu tới Gemini...")

        system_prompt, timeout = cfg["system_prompt"], cfg["timeout"]

        def on_event(kind, payload):           # chạy ở luồng nền
            if kind == "waiting":
                req.phase = "waiting"
            elif kind == "retry":
                req.phase = "retry"
                req.retry_n = payload
            elif kind == "text":
                req.phase = "receiving"
                with req.lock:
                    req.chunks.append(payload)
                    if req.flush_pending:
                        return
                    req.flush_pending = True
                time.sleep(0.08)               # gom nhiều đoạn nhỏ thành một lần vẽ
                self.main.post(lambda: self._flush(req))

        def work():                            # chạy ở luồng nền
            try:
                client = GeminiClient(key, req.model_name, timeout)
                full, finish = client.stream(contents, system_prompt, on_event, lambda: req.cancelled,
                                             structured_config() if req.structured else None)
                self.main.post(lambda: self._finish_ok(req, full, finish))
            except GeminiError as e:
                log("gemini: %s (HTTP %s)" % (e.kind, e.status))
                kind, msg = e.kind, e.message
                self.main.post(lambda: self._finish_error(req, kind, msg))
            except Exception:
                log("gemini: lỗi không xác định\n" + traceback.format_exc())
                self.main.post(lambda: self._finish_error(req, "unknown", "Lỗi không xác định (xem file log)."))
            finally:
                req.done.set()

        def ticker():                          # cập nhật đồng hồ trạng thái mỗi giây
            while not req.done.wait(1.0):
                self.main.post(lambda: self._tick(req))

        run_in_background(work, "aichat-gemini")
        run_in_background(ticker, "aichat-ticker")

    def _current(self, req):
        return (not self.disposed and req is self.req and not req.cancelled
                and req.session_id == self.session.id)

    def _tick(self, req):
        if not self._current(req):
            return
        secs = int(time.time() - req.t0)
        label = {"sending": "Đang gửi yêu cầu", "waiting": "Gemini đang suy nghĩ",
                 "receiving": "Đang nhận phản hồi",
                 "retry": "Gemini quá tải, thử lại lần %d" % getattr(req, "retry_n", 1)}[req.phase]
        self.set_status("%s... %ds" % (label, secs))

    def _flush(self, req):
        with req.lock:
            req.flush_pending = False
            text = "".join(req.chunks)
        if not self._current(req):
            return
        req.model_item["text"] = (partial_result(text) or "…") if req.structured else text
        self.render_history()
        self._tick(req)

    def _finish_ok(self, req, full, finish):
        if not self._current(req):
            return
        item = req.model_item
        item["text"], item["insert_text"] = full, full
        if req.structured:
            parsed = parse_structured(full)
            if parsed and parsed[0]:
                item["text"] = display_structured(parsed[0], parsed[1])
                item["insert_text"] = parsed[0]          # chỉ phần kết quả, không kèm ghi chú
            else:
                item["insert_text"] = None                # không tách được -> không cho chèn/thay
                self.session.add("note", "⚠ AI không trả về đúng định dạng kết quả riêng, nên không thể tách "
                                         "nội dung để Chèn/Thay thế an toàn. Hãy gửi lại yêu cầu.")
        self.req = None
        self._set_busy(False)
        notes = []
        if finish == "MAX_TOKENS":
            notes.append("câu trả lời bị cắt do giới hạn độ dài")
        if req.trimmed:
            notes.append("đã lược bớt lịch sử cũ để vừa giới hạn")
        if notes:
            self.session.add("note", "ℹ " + "; ".join(notes).capitalize() + ".")
        self.render_history()
        self.set_status("Đã nhận phản hồi (%.1f giây)" % (time.time() - req.t0))

    def _finish_error(self, req, kind, msg):
        if not self._current(req):
            return
        self._rollback(req)
        self.session.add("note", "⚠ Lỗi: " + msg)
        self.render_history()
        self.set_status("Lỗi – nội dung đã được trả lại ô nhập, bấm Gửi để thử lại")

    def _rollback(self, req):
        """Bỏ lượt hỏi/đáp thất bại khỏi ngữ cảnh và trả câu hỏi về ô nhập để thử lại."""
        self.session.remove(req.model_item)
        self.session.remove(req.user_item)
        self.req = None
        self._set_busy(False)
        inp = self.ctl("txtInput").getModel()
        if req.input_text and not (inp.Text or "").strip():
            inp.Text = req.input_text
        if req.snapshot is not None and self.snapshot is None:
            self._attach(req.snapshot)  # gắn lại văn bản đã đọc để bấm thử lại

    def cancel_request(self, reason):
        req = self.req
        if req is None:
            return
        self._rollback(req)
        req.cancelled = True  # luồng nền tự dừng; kết quả muộn bị bỏ qua
        if reason:
            self.session.add("note", "ℹ " + reason)
        self.render_history()
        self.set_status(reason or "Sẵn sàng")

    # ---------- nút khác ----------
    def on_new_chat(self):
        if self.req is not None:
            self.req.cancelled = True
            self.req = None
            self._set_busy(False)
        self.session = ChatSession()   # phiên mới, không trộn với phiên cũ
        self.ctl("txtInput").getModel().Text = ""
        self.render_history()
        self.set_status("Đã tạo cuộc hội thoại mới")

    def on_settings(self):
        from aichat.settings_dialog import SettingsDialog
        try:
            parent = self.Frame.getContainerWindow() if self.Frame else None
            SettingsDialog(self.ctx, self.main, log, parent).execute()
        except Exception:
            log("settings dialog: " + traceback.format_exc())
            self.set_status("Không mở được Cài đặt (xem log)")
            return
        if self.req is None:
            self.render_history()
            self.set_status("Sẵn sàng – mô hình: %s" % settings.load(self.ctx)["model"]
                            if self._has_key() else "Chưa có API key – bấm Cài đặt")

    # ---------- XUIElement ----------
    def getRealInterface(self):
        return self

    # ---------- XToolPanel ----------
    def createAccessible(self, parent_accessible):
        return self.Window

    # ---------- XSidebarPanel ----------
    def getHeightForWidth(self, width):
        # Tối thiểu 300px, không giới hạn tối đa (-1) => panel giãn hết chiều cao Deck
        return LayoutSize(300, -1, 400)

    def getMinimalWidth(self):
        # Nhỏ hơn bề rộng Sidebar mặc định để không phát sinh thanh cuộn ngang
        return 160

    # ---------- XComponent ----------
    def dispose(self):
        self.disposed = True
        if self.req is not None:
            self.req.cancelled = True
        try:
            self.parent.removeWindowListener(self._resize)
            self.Window.dispose()
        except Exception:
            log(traceback.format_exc())

    def addEventListener(self, l): pass
    def removeEventListener(self, l): pass


class PanelFactory(unohelper.Base, XUIElementFactory):
    def __init__(self, ctx):
        self.ctx = ctx

    def createUIElement(self, url, args):
        try:
            props = {a.Name: a.Value for a in args}
            parent = props.get("ParentWindow")
            if parent is None:
                raise RuntimeError("Thiếu ParentWindow")
            if url.endswith("/AIChatPanel"):
                return ChatPanel(self.ctx, props.get("Frame"), parent, url)
            raise RuntimeError("Không hỗ trợ: " + url)
        except Exception:
            log(traceback.format_exc())
            raise


g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(
    PanelFactory, IMPL_NAME, ("com.sun.star.ui.UIElementFactory",))
