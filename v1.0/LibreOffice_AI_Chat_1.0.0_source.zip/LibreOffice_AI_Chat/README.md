# AI Chat cho LibreOffice Writer – 1.0.0

Extension đưa trợ lý Google Gemini vào Sidebar của LibreOffice Writer: trò chuyện, phân tích đoạn văn bạn chọn,
chèn/thay thế kết quả vào tài liệu với xác nhận và một bước Undo.

## Cấu trúc dự án

```
extension/                 mã nguồn extension (nội dung file .oxt)
  description.xml          id vn.aichat.writer, phiên bản
  META-INF/manifest.xml    khai báo component Python + cấu hình
  registry/                Sidebar.xcu (deck/panel), Factories.xcu (factory)
  dialogs/ChatPanel.xdl    control của panel
  python/aichat_component.py        panel + điều phối
  python/pythonpath/aichat/         các module (Gemini, tài liệu, Markdown, cài đặt...)
tests/
  run_tests.py             bộ kiểm thử tự động (một lệnh)
  install_test.py          cài/gỡ/cài lại trên hồ sơ LibreOffice sạch
  mock_gemini.py           máy chủ giả lập Gemini (chỉ để kiểm thử)
  docfix.py                tài liệu mẫu cho kiểm thử
tools/build_oxt.py         đóng gói -> dist/LibreOffice_AI_Chat_<version>.oxt
docs/                      hướng dẫn sử dụng, báo cáo kiểm thử, nhật ký thay đổi
dist/                      file phát hành
```

## Đóng gói

```
python tools/build_oxt.py
```

Script kiểm tra manifest, XML, chặn file tạm và chuỗi giống API key trước khi tạo `.oxt`.

## Kiểm thử

Windows (dùng Python của LibreOffice để có module `uno`):

```
"C:\Program Files\LibreOffice\program\python.exe" tests\run_tests.py            # đơn vị + tích hợp UNO
"C:\Program Files\LibreOffice\program\python.exe" tests\run_tests.py --perf     # + tài liệu lớn
"C:\Program Files\LibreOffice\program\python.exe" tests\run_tests.py --unit     # chỉ đơn vị
"C:\Program Files\LibreOffice\program\python.exe" tests\install_test.py dist\LibreOffice_AI_Chat_1.0.0.oxt
```

Linux: `python3 tests/run_tests.py`; `xvfb-run -a python3 tests/install_test.py dist/...oxt`.

Kết quả: `PASS` / `FAIL` (lỗi chức năng) / `ENV` (lỗi môi trường) / `SKIP`. Không dùng Gemini API thật.
Hãy đóng LibreOffice trước khi chạy.

## Cài đặt / gỡ cài đặt

Xem `docs/HuongDanSuDung.md` (hoặc bản PDF), mục 2.
