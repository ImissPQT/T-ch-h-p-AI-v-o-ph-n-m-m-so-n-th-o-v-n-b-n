---
title: "AI Chat cho LibreOffice Writer – Hướng dẫn sử dụng"
subtitle: "Phiên bản 1.0.0"
---

# 1. Giới thiệu

**AI Chat cho Writer** là extension giúp bạn trò chuyện với trợ lý AI **Google Gemini** ngay trong khung bên phải
(Sidebar) của LibreOffice Writer: hỏi đáp, tóm tắt, giải thích, sửa chính tả, viết lại, dịch đoạn văn bạn chọn,
rồi chèn hoặc thay thế kết quả vào tài liệu, có thể hoàn tác bằng **một lần Ctrl+Z**.

Nguyên tắc an toàn:

- Extension **không bao giờ tự đọc hay gửi toàn bộ tài liệu**. Chỉ đoạn bạn bôi đen và bấm *Đọc văn bản đã chọn* mới
  được hiển thị lại để bạn kiểm tra, và chỉ được gửi khi bạn bấm một thao tác.
- Extension **không tự sửa tài liệu**. Chèn/Thay thế chỉ xảy ra khi bạn bấm nút; Thay thế luôn hỏi xác nhận.
- Tin nhắn được gửi tới **Google Gemini API qua Internet** và áp dụng chính sách dữ liệu của Google. Với Free Tier,
  Google có thể dùng nội dung để cải thiện sản phẩm. **Không gửi thông tin nhạy cảm.**

# 2. Cài đặt

## 2.1. Yêu cầu hệ thống

| Thành phần | Yêu cầu |
|---|---|
| Hệ điều hành | Windows 10/11 (đã kiểm thử). Linux chạy được với hạn chế lưu key (mục 4.2) |
| LibreOffice | **24.2** (đã kiểm thử). Khuyến nghị từ 7.4 trở lên; các bản cũ hơn chưa được kiểm thử |
| Thành phần Python của LibreOffice | Có sẵn trong bộ cài LibreOffice cho Windows |
| Internet | Cần để kết nối Gemini API |
| Tài khoản Google | Để tạo API key miễn phí |

## 2.2. Cài extension

1. Mở LibreOffice ▸ **Công cụ ▸ Trình quản lý phần mở rộng** (*Tools ▸ Extension Manager*), hoặc nhấn **Ctrl+Alt+E**.
2. Bấm **Thêm…** (*Add…*) ▸ chọn file `LibreOffice_AI_Chat_1.0.0.oxt` ▸ chọn *Chỉ cho tôi* (*Only for me*).
3. **Khởi động lại LibreOffice** (đóng hết các cửa sổ LibreOffice rồi mở lại).

Cài bằng dòng lệnh (tùy chọn):

```
"C:\Program Files\LibreOffice\program\unopkg.com" add LibreOffice_AI_Chat_1.0.0.oxt
```

## 2.3. Nâng cấp từ bản thử nghiệm (0.x)

Gỡ bản cũ trước (mục 2.5), rồi cài bản 1.0.0. API key và cài đặt đã lưu **được giữ nguyên**.

## 2.4. Mở khung AI Chat

- Mở một tài liệu Writer ▸ bấm **biểu tượng bong bóng chat màu xanh** trên thanh dọc ở cạnh phải.
- Nếu không thấy thanh dọc: **Xem ▸ Thanh bên** (*View ▸ Sidebar*) hoặc **Ctrl+F5**.
- Nếu thanh dọc có nhưng thiếu biểu tượng: bấm nút **≡** ở đầu thanh ▸ **Tùy biến** (*Customization*) ▸ đánh dấu **AI Chat**.
- Bấm dấu **X** ở góc khung chỉ thu gọn khung; bấm lại biểu tượng bong bóng để mở lại.

## 2.5. Gỡ cài đặt

1. **Công cụ ▸ Trình quản lý phần mở rộng** ▸ chọn **AI Chat cho Writer** ▸ **Gỡ bỏ** (*Remove*) ▸ khởi động lại LibreOffice.
2. (Tùy chọn) Xóa API key: **Control Panel ▸ Credential Manager ▸ Windows Credentials** ▸ xóa mục
   `LibreOffice AI Chat/Gemini` (hoặc bấm **Xóa key** trong Cài đặt *trước khi* gỡ).
3. (Tùy chọn) Xóa cài đặt: thư mục `%APPDATA%\LibreOffice\4\user\aichat\`.

# 3. Thiết lập AI

## 3.1. Tạo Gemini API key (miễn phí)

1. Mở <https://aistudio.google.com/apikey> và đăng nhập tài khoản Google.
2. Bấm **Create API key** ▸ sao chép chuỗi key (bắt đầu bằng `AIza…`).
3. Giữ key như mật khẩu, không chia sẻ cho người khác.

## 3.2. Nhập API key

1. Trong khung AI Chat, bấm **Cài đặt**.
2. Dán key vào ô **API Key Gemini** (ô hiển thị dấu `*`) ▸ bấm **Lưu key**.
3. Dòng *Trạng thái* hiện **ĐÃ LƯU API key trong Windows Credential Manager**.

Key được Windows mã hóa theo tài khoản của bạn; không nằm trong file cấu hình, file log hay khung chat.

## 3.3. Kiểm tra kết nối

Bấm **Kiểm tra kết nối**. Việc kiểm tra gồm hai bước:

- **Bước 1 – Internet và API key**: lấy danh sách mô hình từ Google.
- **Bước 2 – Mô hình**: hỏi thử mô hình đang chọn một câu ngắn (chờ tối đa 60 giây).

Kết quả cho biết bước nào lỗi để bạn xử lý đúng chỗ (xem mục 6).

## 3.4. Chọn mô hình

- Mặc định: `gemini-3.8-flash`. Có thể chọn trong danh sách hoặc gõ tên khác.
- Bấm **Tải danh sách** để lấy các mô hình mà key của bạn dùng được.
- Nên dùng các mô hình **Flash / Flash-Lite**: có Free Tier (kiểm tra tại <https://ai.google.dev/pricing>).
  Nếu hay gặp lỗi quá tải hoặc hết hạn mức, chọn `gemini-3.5-flash-lite`.
- **System prompt**: hướng dẫn chung cho AI (giọng văn, ngôn ngữ trả lời…). Bấm **Mặc định** để khôi phục.
- Bấm **Lưu và đóng** để lưu. Cài đặt được giữ khi mở lại LibreOffice.

# 4. Sử dụng

## 4.1. Trò chuyện với AI

1. Gõ câu hỏi vào ô dưới cùng ▸ bấm **Gửi** hoặc **Ctrl+Enter** (Enter thường để xuống dòng).
2. Câu trả lời hiện dần trong khung chat. Dòng trạng thái cho biết: *Đang gửi yêu cầu* ▸ *Gemini đang suy nghĩ… Ns*
   ▸ *Đang nhận phản hồi* ▸ *Đã nhận phản hồi*.
3. Khi đang chờ, nút Gửi đổi thành **Dừng** để hủy yêu cầu.
4. AI nhớ các câu trước trong cùng cuộc trò chuyện. **Chat mới** bắt đầu cuộc trò chuyện mới (xóa lịch sử).

Lịch sử chat không được lưu khi đóng cửa sổ tài liệu.

## 4.2. Đọc văn bản đã chọn

1. Bôi đen đoạn cần dùng trong tài liệu: một câu, nhiều đoạn, nhiều vùng (giữ Ctrl khi bôi đen) hoặc các ô bảng.
2. Bấm **Đọc văn bản đã chọn**. Khung chat hiện số đoạn, số ký tự và **toàn bộ nội dung đã đọc** để bạn kiểm tra.
   **Lúc này chưa có gì được gửi đi.**
3. Bấm **Bỏ** nếu đọc nhầm, hoặc bôi đen lại rồi bấm **Đọc lại vùng chọn**.

Nếu bạn đổi vùng chọn sau khi đọc, extension vẫn gửi đúng nội dung đang hiện trong khung (và có ghi chú báo việc này).

## 4.3. Phân tích văn bản

Sau khi đọc, chọn một thao tác:

| Nút | Kết quả |
|---|---|
| Tóm tắt | Các ý chính dạng gạch đầu dòng |
| Giải thích | Giải thích dễ hiểu, làm rõ thuật ngữ |
| Phân tích | Chủ đề, cấu trúc, điểm mạnh, điểm cần cải thiện |
| Sửa chính tả | Liệt kê lỗi chính tả/ngữ pháp và cách sửa |
| Viết lại | Bản viết lại mạch lạc hơn (+ ghi chú thay đổi) |
| Dịch | Tiếng Việt ▸ tiếng Anh; ngôn ngữ khác ▸ tiếng Việt |

Hoặc gõ yêu cầu riêng (ví dụ *"dịch sang tiếng Nhật"*, *"rút gọn còn 2 câu"*) rồi bấm **Gửi**.

Mỗi lần đọc chỉ gửi **một lần**; muốn hỏi tiếp về cùng đoạn, cứ gõ tiếp (AI vẫn nhớ), hoặc đọc lại.

## 4.4. Copy và Chèn

Ba nút dưới khung chat luôn áp dụng cho **câu trả lời AI mới nhất** (mờ đi khi không dùng được):

- **Copy**: chép câu trả lời vào Clipboard. Với *Viết lại*/*Dịch* chỉ chép phần kết quả.
- **Chèn**: chèn tại vị trí con trỏ. Nếu đang bôi đen, nội dung được chèn **ngay sau** vùng bôi đen (không xóa gì).
  Markdown được chuyển thành định dạng Writer thật: tiêu đề (Heading 1–3), danh sách gạch đầu dòng / đánh số,
  in đậm, in nghiêng, chữ code (font Liberation Mono), khối code (*Preformatted Text*).

## 4.5. Thay thế văn bản

Dùng cho câu trả lời của một thao tác trên *văn bản đã chọn* (một vùng liền mạch):

1. Bấm **Thay thế**. Extension kiểm tra đoạn gốc trong tài liệu **còn nguyên văn** như lúc gửi.
2. Hộp thoại hiện **Nội dung TRƯỚC** và **Nội dung SAU**. Nút mặc định là **Hủy**.
3. Bấm **Xác nhận thay thế** để thay.

Extension **từ chối thay thế** (và báo lý do) khi đoạn gốc đã bị sửa hoặc xóa trong lúc chờ AI, hoặc tài liệu đã đóng.
Extension không bao giờ "đoán" vị trí mới. Với *Viết lại*/*Dịch*, chỉ phần kết quả được đưa vào, không kèm lời dẫn
hay giải thích của AI.

Không thay thế được khi vùng đã đọc gồm nhiều vùng rời nhau hoặc ô bảng; hãy dùng **Chèn**.

## 4.6. Hoàn tác (Undo)

Mỗi lần Chèn hoặc Thay thế là **một bước hoàn tác** có tên *AI Chat: Chèn nội dung* / *AI Chat: Thay thế đoạn văn*.
Nhấn **Ctrl+Z một lần** (hoặc **Sửa ▸ Hoàn tác**) để khôi phục toàn bộ.

# 5. Cài đặt nâng cao

Bản 1.0.0 có: API key, mô hình, system prompt. Các thiết lập sau **dự kiến có ở bản tiếp theo**:
độ sáng tạo (temperature), giới hạn độ dài trả lời, mức suy nghĩ (thinking level), thời gian chờ tùy chỉnh,
thống kê token, chuyển ngôn ngữ giao diện Việt/Anh.

Giá trị đang dùng ở bản 1.0.0: thời gian chờ phản hồi 120 giây; tự thử lại 2 lần khi Gemini quá tải (lỗi 503);
gửi kèm tối đa ~120.000 ký tự lịch sử hội thoại (phần cũ hơn được lược bớt và có ghi chú); một tin nhắn tối đa 100.000 ký tự.

# 6. Xử lý sự cố

| Thông báo / hiện tượng | Nguyên nhân thường gặp | Cách xử lý |
|---|---|---|
| *API key không hợp lệ hoặc đã hết hạn* | Key sai, thiếu ký tự, đã bị xóa | Tạo key mới, dán lại, **Lưu key**, **Kiểm tra kết nối** |
| *Bước 1 thất bại: không kết nối được / hết thời gian chờ* | Mất Internet, tường lửa, proxy, phần mềm diệt virus chặn LibreOffice | Kiểm tra mạng; cho phép `soffice.bin` truy cập Internet |
| *Lỗi bảo mật kết nối (SSL)* | Đồng hồ máy sai, proxy/antivirus kiểm tra HTTPS | Chỉnh giờ hệ thống; tắt quét HTTPS cho LibreOffice |
| *Bước 2 thất bại / mô hình quá tải (503)* | Mô hình đang quá tải phía Google | Chờ vài phút hoặc chọn `gemini-3.5-flash-lite` |
| *Đã chạm giới hạn của Free Tier (429)* | Hết lượt mỗi phút/ngày của Free Tier | Chờ (giới hạn ngày đặt lại lúc nửa đêm giờ Thái Bình Dương) hoặc đổi mô hình Flash-Lite |
| *Không tìm thấy mô hình* | Tên mô hình sai hoặc đã ngừng | Cài đặt ▸ **Tải danh sách** ▸ chọn mô hình khác |
| *Nội dung quá dài* | Tin nhắn/vùng chọn/lịch sử quá dài | Chọn đoạn ngắn hơn hoặc bấm **Chat mới** |
| *Gemini từ chối trả lời do bộ lọc an toàn* | Nội dung bị bộ lọc của Google chặn | Diễn đạt lại yêu cầu |
| *Chưa có văn bản nào được bôi đen* | Chỉ đặt con trỏ, chưa bôi đen | Bôi đen đoạn cần dùng rồi bấm lại |
| *Bạn đang chọn hình ảnh/khung* | Đang chọn đối tượng không phải chữ | Bôi đen phần chữ |
| *Không thay thế: đoạn văn gốc đã bị sửa/xóa* | Tài liệu bị sửa trong lúc chờ AI | Đọc lại vùng chọn và gửi lại |
| *AI không trả về đúng định dạng kết quả riêng* | Hiếm khi xảy ra với Viết lại/Dịch | Gửi lại yêu cầu |
| Nút Chèn/Thay thế bị mờ | Chưa có câu trả lời phù hợp, hoặc đang chờ AI | Xem mục 4.4–4.5 |
| Không thấy khung AI Chat | Thanh bên bị tắt / biểu tượng bị ẩn | Mục 2.4 |
| Extension không chạy sau khi cài | Chưa khởi động lại LibreOffice; thiếu thành phần Python | Khởi động lại; cài lại LibreOffice với thành phần mặc định |

**File log** (để gửi khi báo lỗi): `%TEMP%\aichat_writer.log`. Log chỉ ghi loại lỗi và mã HTTP,
**không** chứa API key hay nội dung tin nhắn.

# 7. Câu hỏi thường gặp

**Extension có gửi cả tài liệu của tôi lên Google không?** Không. Chỉ tin nhắn bạn gõ và đoạn bạn chủ động
*Đọc văn bản đã chọn* rồi bấm thao tác.

**Có mất phí không?** Extension miễn phí. Gemini API có Free Tier; bạn chỉ trả phí nếu tự bật thanh toán trong Google AI Studio.

**Key lưu ở đâu?** Windows Credential Manager, mục `LibreOffice AI Chat/Gemini`.
