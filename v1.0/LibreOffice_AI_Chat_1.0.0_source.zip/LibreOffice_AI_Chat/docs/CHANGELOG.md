# Nhật ký thay đổi

## 1.0.0 – 16/11/2026 (phát hành đầu tiên)

- Khung AI Chat trong Sidebar của Writer (Giai đoạn 1–2).
- Kết nối Google Gemini API qua HTTPS (streaming), trạng thái gửi/suy nghĩ/nhận, nút Dừng, Ctrl+Enter,
  tự thử lại khi quá tải, thông báo lỗi tiếng Việt (Giai đoạn 3–4).
- API key lưu trong Windows Credential Manager; Cài đặt: key, kiểm tra kết nối 2 bước, mô hình, system prompt.
- Đọc văn bản đã chọn (câu, nhiều đoạn, nhiều vùng, ô bảng), xem trước trước khi gửi; 6 thao tác:
  Tóm tắt, Giải thích, Phân tích, Sửa chính tả, Viết lại, Dịch (Giai đoạn 5).
- Copy / Chèn (Markdown → định dạng Writer thật) / Thay thế an toàn có xác nhận, một bước Undo;
  Viết lại/Dịch trả về JSON có cấu trúc để chỉ chèn phần kết quả (Giai đoạn 6).
- Bộ kiểm thử tự động, kiểm thử cài đặt sạch, kiểm thử tài liệu lớn, hướng dẫn sử dụng (Giai đoạn 8).

## Dự kiến cho bản sau

- Cài đặt nâng cao: temperature, giới hạn token đầu ra, thinking level, timeout (Giai đoạn 7).
- Thống kê token theo yêu cầu và theo phiên (dùng `usageMetadata` của API).
- Giao diện và thông báo song ngữ Việt/Anh.
- Mục menu *Công cụ ▸ AI Chat* và phím tắt bật/tắt khung chat.
