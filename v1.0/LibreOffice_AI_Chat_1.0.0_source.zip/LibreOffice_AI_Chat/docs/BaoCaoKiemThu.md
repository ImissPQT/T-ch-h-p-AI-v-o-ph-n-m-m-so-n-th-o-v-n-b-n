---
title: "AI Chat cho LibreOffice Writer – Báo cáo kiểm thử phiên bản 1.0.0"
---

# 1. Tóm tắt

| Hạng mục | Kết quả |
|---|---|
| Bộ kiểm thử tự động (`tests/run_tests.py --perf`) | **27 PASS / 0 FAIL / 0 ENV** |
| Cài / gỡ / cài lại trên hồ sơ LibreOffice sạch (`tests/install_test.py`) | **6 PASS / 0 FAIL** |
| Kiểm thử giao diện tổng thể (Sidebar thật, tài liệu 472 trang) | Đạt (mục 4) |
| Người dùng kiểm thử trên Windows với Gemini API thật | Người dùng xác nhận đạt các giai đoạn 1–6 (16/11/2026) |
| Gói phát hành | `LibreOffice_AI_Chat_1.0.0.oxt`, 24 file, 42 KB |
| SHA-256 | `5ff880a293dd95e9e5e1ce84979f7ecb21f14b57008013dd18c8511d77ef6fb8` |

# 2. Môi trường

| | Kiểm thử tự động / giao diện (nhà phát triển) | Kiểm thử thực tế (người dùng) |
|---|---|---|
| Hệ điều hành | Linux, màn hình ảo Xvfb | Windows |
| LibreOffice | 24.2.7.2 | 24.2 |
| Python | 3.13 (mã được kiểm tra cú pháp Python 3.8) | Python đi kèm LibreOffice |
| Gemini API | **Máy chủ giả lập cục bộ** (không có Internet) | **Gemini API thật** |
| Lưu API key | Kho mật khẩu LibreOffice | Windows Credential Manager |

# 3. Kiểm thử tự động (27 bài)

Chạy bằng một lệnh: `python tests/run_tests.py --perf` (Windows: dùng `python.exe` của LibreOffice).
Kết quả chi tiết: `docs/ketqua_run_tests.txt`.

| Nhóm (module) | Số bài | Nội dung chính | Kết quả |
|---|---|---|---|
| Markdown (`md_parse`, `markdown_text`) | 4 | khối, định dạng trong dòng, ký tự thoát, 5.000 dòng < 2 s | PASS |
| Hội thoại (`chat_session`) | 3 | ngữ cảnh, cắt lịch sử theo ngân sách, tách phiên | PASS |
| Gemini API – mock (`gemini_client`) | 6 | streaming, lọc "thought", key nằm trong header; lỗi 400/429/404/JSON; tự thử lại 503; timeout; mất mạng; chặn máy chủ lạ; kiểm tra kết nối 2 bước | PASS |
| Viết lại / Dịch – JSON (`prompts`) | 2 | tách result/notes, JSON dở dang, phản hồi sai định dạng; gửi `responseJsonSchema` | PASS |
| Đọc vùng chọn (`document`) | 2 | câu, nhiều đoạn, ô bảng, nhiều vùng; chưa chọn; tài liệu không bị đánh dấu sửa | PASS |
| Neo vùng gốc (`document`) | 1 | cho phép: không đổi / sửa phía trước / đổi vùng chọn; từ chối: sửa / xóa / tài liệu đã đóng | PASS |
| Chèn văn bản (`writer_insert`) | 2 | đầu, giữa câu, giữa tài liệu, cuối; Heading 1–3, danh sách Writer thật, đậm/nghiêng, font code, không còn ký hiệu Markdown | PASS |
| Thay thế văn bản (`writer_insert`) | 1 | một câu, nhiều đoạn | PASS |
| Undo (`writer_insert`) | 2 | chèn/thay thế = 1 bước; 1 lần undo khôi phục; lỗi giữa chừng tự hoàn tác, không để lại bước rỗng | PASS |
| Clipboard | 1 | câu ngắn; ~20.000 ký tự tiếng Việt | PASS |
| Cài đặt (`settings`) | 1 | lưu/đọc; giá trị sai kiểu và file hỏng → mặc định; không chứa API key | PASS |
| Lưu API key (`secret_store`) | 1 | Linux: kho LibreOffice. Trên Windows bài này dùng Credential Manager thật với mục thử riêng | PASS (Linux) |
| Tài liệu lớn (`--perf`) | 1 | xem mục 5 | PASS |

**Thống kê token:** chưa có trong bản 1.0.0 (dự kiến ở bản sau), nên chưa có bài kiểm thử.

# 4. Kiểm thử tổng thể bằng giao diện (bản phát hành)

Cài `LibreOffice_AI_Chat_1.0.0.oxt`, thao tác bằng chuột/bàn phím giả lập trên màn hình ảo:

| # | Bước | Kết quả |
|---|---|---|
| 1 | Cài extension (hồ sơ sạch, qua Extension Manager API) | Đạt |
| 2–3 | Mở Writer, mở Sidebar AI Chat (tài liệu 472 trang) | Đạt – mở deck 0,11 s |
| 4 | Lưu key, kiểm tra kết nối | Đạt (mock) |
| 5 | Gửi 10 tin nhắn liên tiếp | Đạt – không lỗi, yêu cầu cuối mang đủ 19 lượt ngữ cảnh |
| 6–7 | Đọc 2 đoạn giữa tài liệu, Dịch | Đạt |
| 8 | Copy | Đạt (kiểm tra ở các giai đoạn trước + bài tự động) |
| 9 | Chèn | Đạt (giai đoạn 6 + bài tự động) |
| 10 | Thay thế + xác nhận | Đạt – chỉ 2 đoạn đích bị thay |
| 11 | Ctrl+Z bằng bàn phím | Đạt – 6.500 đoạn khớp mã băm với bản gốc |
| 12 | Cài đặt: đổi mô hình, khởi động lại LibreOffice | Đạt – giá trị được giữ |
| 13 | Thống kê token | Không áp dụng (chưa có ở 1.0.0) |
| 14 | Chuyển ngôn ngữ | Không áp dụng (chưa có ở 1.0.0) |
| – | Gỡ cài đặt, cài lại | Đạt – Sidebar mất khi gỡ, hoạt động lại sau khi cài lại |

# 5. Hiệu năng với tài liệu lớn

Tài liệu tiếng Việt khổ A4 (tiêu đề + đoạn văn). Thời gian đo qua cầu nối UNO từ tiến trình bên ngoài, nên là
**giới hạn trên**; khi chạy trong extension sẽ nhanh hơn.

| Trang (thực) | Đoạn | Đọc 20 đoạn (~5.900 ký tự) | Chèn 202 khối Markdown | Thay thế | 2 lần Undo | RAM soffice |
|---|---|---|---|---|---|---|
| 48 | 650 | 0,008 s | 0,94 s | 0,10 s | 0,17 s | 196 MB |
| 95 | 1.300 | 0,008 s | 0,93 s | 0,14 s | 0,20 s | 207 MB |
| 189 | 2.600 | 0,009 s | 1,00 s | 0,16 s | 0,28 s | 222 MB |
| 472 | 6.500 | 0,008 s | 0,97 s | 0,40 s | 0,38 s | 267 MB |

Nhận xét: thời gian đọc vùng chọn và chèn **không phụ thuộc độ dài tài liệu** (extension chỉ làm việc với vùng chọn,
không đọc toàn bộ). RAM tăng theo kích thước tài liệu (do LibreOffice), không do extension.

# 6. Lỗi phát hiện và đã sửa trong đợt phát hành

| Lỗi | Phát hiện bởi | Xử lý |
|---|---|---|
| Khai báo `LibreOffice-minimal-version 7.4` khiến LibreOffice 24.2 **từ chối cài** ("unsatisfied dependencies") | Kiểm thử cài đặt trên hồ sơ sạch | Bỏ khai báo; yêu cầu phiên bản ghi trong hướng dẫn |
| Hai bài kiểm thử có kỳ vọng sai (đếm ký tự UTF-8, chỉ số đoạn) | Lần chạy đầu | Sửa bài kiểm thử (không phải lỗi extension) |
| Bài hiệu năng tạo tài liệu chỉ bằng ½ số trang mục tiêu; đo RAM nhầm tiến trình khởi chạy | Rà soát số liệu | Sửa bộ tạo tài liệu và cách đo RAM |

# 7. Chưa được kiểm thử / giới hạn đã biết

- **Hệ thống tự động chưa chạy trên Windows**: các bài tự động chạy trên Linux; trên Windows, người dùng đã kiểm thử
  thủ công toàn bộ chức năng với Gemini thật. Nên chạy `tests\run_tests.py` một lần trên Windows bằng `python.exe` của
  LibreOffice (bài *Lưu API key* khi đó dùng Credential Manager thật).
- Các phiên bản LibreOffice khác 24.2 chưa được kiểm thử.
- Bài tự động dùng mock API, không đo hạn mức hay độ trễ thật của Gemini.
- Đo RAM chỉ thực hiện trên Linux.
- Chọn nhiều vùng rời nhau bằng Ctrl+kéo chuột: kiểm thử bằng đối tượng giả lập (logic), chưa thao tác thật.
- Chưa có: cài đặt nâng cao (temperature, giới hạn token, thinking level, timeout tùy chỉnh), thống kê token,
  giao diện song ngữ.
