# -*- coding: utf-8 -*-
"""Đóng gói extension thành dist/LibreOffice_AI_Chat_<version>.oxt

Chạy:  python tools/build_oxt.py
Kiểm tra trước khi đóng gói:
  - mọi file khai báo trong META-INF/manifest.xml đều tồn tại
  - mọi file .xml/.xcu/.xdl đều là XML hợp lệ
  - không đưa file tạm (__pycache__, *.pyc, *.log, *.bak, .DS_Store...) vào gói
  - không có chuỗi giống Google API key (AIza...) trong bất kỳ file nào
"""
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXT = os.path.join(ROOT, "extension")
DIST = os.path.join(ROOT, "dist")
EXCLUDE_DIRS = {"__pycache__", ".git", ".idea", ".vscode"}
EXCLUDE_EXT = (".pyc", ".pyo", ".log", ".bak", ".tmp", ".orig", ".swp")
EXCLUDE_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini", "README.md"}
KEY_PATTERN = re.compile(rb"AIza[0-9A-Za-z_\-]{30,}")
NS_MANIFEST = "{http://openoffice.org/2001/manifest}"


def fail(msg):
    print("LỖI: " + msg)
    sys.exit(1)


def version():
    tree = ET.parse(os.path.join(EXT, "description.xml"))
    for el in tree.iter():
        if el.tag.endswith("version"):
            return el.attrib["value"]
    fail("description.xml không có <version>")


def collect():
    files = []
    for d, dirs, names in os.walk(EXT):
        dirs[:] = sorted(x for x in dirs if x not in EXCLUDE_DIRS)
        for n in sorted(names):
            if n in EXCLUDE_NAMES or n.endswith(EXCLUDE_EXT):
                continue
            full = os.path.join(d, n)
            files.append((full, os.path.relpath(full, EXT).replace(os.sep, "/")))
    return files


def check(files):
    rel = {r for _, r in files}
    tree = ET.parse(os.path.join(EXT, "META-INF", "manifest.xml"))
    for entry in tree.getroot():
        path = entry.attrib.get(NS_MANIFEST + "full-path")
        if path not in rel:
            fail("manifest khai báo '%s' nhưng file không tồn tại" % path)
    for full, r in files:
        if r.endswith((".xml", ".xcu", ".xdl")):
            try:
                ET.parse(full)
            except ET.ParseError as e:
                fail("XML không hợp lệ: %s (%s)" % (r, e))
        with open(full, "rb") as f:
            if KEY_PATTERN.search(f.read()):
                fail("Phát hiện chuỗi giống API key trong %s – không đóng gói!" % r)
    for must in ("description.xml", "META-INF/manifest.xml", "python/aichat_component.py",
                 "registry/Sidebar.xcu", "registry/Factories.xcu", "dialogs/ChatPanel.xdl"):
        if must not in rel:
            fail("thiếu file bắt buộc: " + must)


def main():
    files = collect()
    check(files)
    os.makedirs(DIST, exist_ok=True)
    out = os.path.join(DIST, "LibreOffice_AI_Chat_%s.oxt" % version())
    if os.path.exists(out):
        os.remove(out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        # mimetype không bắt buộc với .oxt; giữ thứ tự ổn định để bản build tái lập được
        for full, r in files:
            z.write(full, r)
    print("Đã đóng gói %d file -> %s (%d KB)" % (len(files), out, os.path.getsize(out) // 1024))
    for _, r in files:
        print("   " + r)


if __name__ == "__main__":
    main()
