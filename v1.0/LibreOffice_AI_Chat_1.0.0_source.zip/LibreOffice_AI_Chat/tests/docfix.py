# Tạo tài liệu mẫu và các hàm chọn vùng (dùng chung cho các bài test)
import uno, time
from com.sun.star.text.ControlCharacter import PARAGRAPH_BREAK

PARAS = [
    "Hà Nội là thủ đô của Việt Nam.",
    "Thành phố có lịch sử hơn một nghìn năm, với nhiều di tích như Văn Miếu – Quốc Tử Giám.",
    "Mùa thu Hà Nội nổi tiếng với hương hoa sữa và cốm làng Vòng.",
    "Đoạn cuối: tài liệu này dùng để kiểm thử AI Chat.",
]

def connect(port=2003):
    ctx = uno.getComponentContext()
    res = ctx.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", ctx)
    for i in range(60):
        try:
            return res.resolve("uno:socket,host=localhost,port=%d;urp;StarOffice.ComponentContext" % port)
        except Exception:
            time.sleep(1)

def build(doc):
    text = doc.Text
    text.setString("")
    cur = text.createTextCursor()
    for i, p in enumerate(PARAS):
        text.insertString(cur, p, False)
        if i < len(PARAS) - 1:
            text.insertControlCharacter(cur, PARAGRAPH_BREAK, False)
    text.insertControlCharacter(cur, PARAGRAPH_BREAK, False)
    table = doc.createInstance("com.sun.star.text.TextTable")
    table.initialize(2, 2)
    text.insertTextContent(cur, table, False)
    for name, v in (("A1", "Tỉnh"), ("B1", "Dân số"), ("A2", "Huế"), ("B2", "1.2 triệu")):
        table.getCellByName(name).setString(v)
    doc.setModified(False)
    return table

def para_range(doc, start, end_incl):
    """Vùng chọn từ đầu đoạn start tới hết đoạn end_incl."""
    enum = doc.Text.createEnumeration()
    paras = []
    while enum.hasMoreElements():
        e = enum.nextElement()
        if e.supportsService("com.sun.star.text.Paragraph"):
            paras.append(e)
    cur = doc.Text.createTextCursorByRange(paras[start].getStart())
    cur.gotoRange(paras[end_incl].getEnd(), True)
    return cur

def select_paras(doc, a, b):
    doc.CurrentController.select(para_range(doc, a, b))

def select_none(doc):
    vc = doc.CurrentController.getViewCursor()
    vc.gotoStart(False)
    doc.CurrentController.select(vc.getStart())

def select_cells(doc, table, rng="A1:B2"):
    doc.CurrentController.select(table.getCellRangeByName(rng))
