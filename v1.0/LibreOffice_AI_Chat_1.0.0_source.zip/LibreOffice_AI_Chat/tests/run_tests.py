# -*- coding: utf-8 -*-
"""Bộ kiểm thử tự động – AI Chat cho LibreOffice Writer.

Chạy (một lệnh):
  Windows : "C:\\Program Files\\LibreOffice\\program\\python.exe" tests\\run_tests.py
  Linux   : python3 tests/run_tests.py
Tùy chọn:
  --unit          chỉ chạy kiểm thử đơn vị (không cần LibreOffice)
  --perf          chạy thêm kiểm thử hiệu năng với tài liệu lớn (50/100/200/500 trang)
  --soffice PATH  đường dẫn soffice nếu không tự tìm thấy
  -v              in chi tiết lỗi

Kết quả: PASS / FAIL (lỗi chức năng) / ENV (lỗi môi trường: thiếu LibreOffice, không kết nối được...)
/ SKIP (không áp dụng cho hệ điều hành này). Không dùng Gemini API thật: mọi bài dùng máy chủ giả lập cục bộ.
Mã thoát: 0 nếu không có FAIL.
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "extension", "python", "pythonpath"))
sys.path.insert(0, HERE)

ARGS = sys.argv[1:]
VERBOSE = "-v" in ARGS


class EnvError(Exception):
    """Lỗi môi trường (không phải lỗi của extension)."""


class Skip(Exception):
    pass


TESTS = []


def test(group, needs_uno=False, perf=False):
    def deco(fn):
        TESTS.append((group, fn.__doc__ or fn.__name__, fn, needs_uno, perf))
        return fn
    return deco


def eq(a, b, msg=""):
    if a != b:
        raise AssertionError("%s\n   mong đợi: %r\n   thực tế : %r" % (msg, b, a))


# =============================================================== MÁY CHỦ GIẢ LẬP GEMINI
MOCK = {}


def start_mock():
    import mock_gemini
    from http.server import ThreadingHTTPServer
    mock_gemini.LOG = os.path.join(tempfile.gettempdir(), "aichat_test_requests.jsonl")
    if os.path.exists(mock_gemini.LOG):
        os.remove(mock_gemini.LOG)
    class Quiet(ThreadingHTTPServer):
        def handle_error(self, request, client_address):
            pass   # client chủ động ngắt (bài test timeout) -> không in traceback gây nhiễu

    srv = Quiet(("127.0.0.1", 0), mock_gemini.H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    os.environ["AICHAT_TEST_BASE_URL"] = "http://127.0.0.1:%d/v1beta" % srv.server_address[1]
    MOCK.update(srv=srv, key=mock_gemini.GOOD_KEY, log=mock_gemini.LOG)


def mock_requests():
    with open(MOCK["log"], encoding="utf-8") as f:
        return [json.loads(l) for l in f]


def user(text):
    return [{"role": "user", "parts": [{"text": text}]}]


# =============================================================== KIỂM THỬ ĐƠN VỊ
@test("Markdown")
def t_md_blocks():
    """Phân tích khối: tiêu đề, danh sách, đánh số, code, trích dẫn, bảng"""
    from aichat.md_parse import parse_blocks
    b = parse_blocks("# A\n## B\n### C\n- x\n  - y\n1. m\n2. n\n```py\ncode **k**\n```\n> q\n| a | b |\n|---|---|\nthường")
    eq([x["type"] for x in b], ["heading", "heading", "heading", "bullet", "bullet", "ordered", "ordered", "code",
                                "quote", "para", "para"])
    eq([x.get("level") for x in b[:5]], [1, 2, 3, 0, 1])
    eq(b[7]["lines"], ["code **k**"], "code giữ nguyên")


@test("Markdown")
def t_md_inline():
    """Định dạng trong dòng: đậm, nghiêng, đậm+nghiêng, code, gạch, liên kết, ký tự thoát"""
    from aichat.md_parse import parse_inline
    r = parse_inline("a **b** *c* ***d*** `e*f*` ~~g~~ [h](http://x.y) \\*i\\* snake_case 2*3*4")
    got = [(t, f["b"], f["i"], f["code"], f["s"], f["link"]) for t, f in r]
    eq(got, [("a ", 0, 0, 0, 0, ""), ("b", 1, 0, 0, 0, ""), (" ", 0, 0, 0, 0, ""), ("c", 0, 1, 0, 0, ""),
             (" ", 0, 0, 0, 0, ""), ("d", 1, 1, 0, 0, ""), (" ", 0, 0, 0, 0, ""), ("e*f*", 0, 0, 1, 0, ""),
             (" ", 0, 0, 0, 0, ""), ("g", 0, 0, 0, 1, ""), (" ", 0, 0, 0, 0, ""), ("h", 0, 0, 0, 0, "http://x.y"),
             (" *i* snake_case 2*3*4", 0, 0, 0, 0, "")])


@test("Markdown")
def t_md_plain():
    """Markdown -> văn bản hiển thị trong khung chat"""
    from aichat.markdown_text import to_plain
    eq(to_plain("## T\n- **a**\n`x`"), "■ T\n• a\n‘x’")


@test("Markdown")
def t_md_speed():
    """Tốc độ: phân tích 5.000 dòng Markdown < 2 giây"""
    from aichat.md_parse import parse_blocks
    md = "\n".join("- mục **%d** có `code` và *nghiêng*" % i for i in range(5000))
    t0 = time.time()
    n = len(parse_blocks(md))
    dt = time.time() - t0
    eq(n, 5000)
    assert dt < 2, "quá chậm: %.2fs" % dt


@test("Hội thoại")
def t_session_context():
    """Ngữ cảnh: chỉ gửi lượt user/model, bỏ ghi chú, bắt đầu bằng user"""
    from aichat.chat_session import ChatSession
    s = ChatSession()
    s.add("note", "x")
    s.add("user", "u1")
    s.add("model", "m1")
    s.add("user", "u2")
    c, trimmed = s.build_contents(10000)
    eq([x["role"] for x in c], ["user", "model", "user"])
    eq(trimmed, False)


@test("Hội thoại")
def t_session_budget():
    """Cắt bớt lịch sử cũ khi vượt ngân sách ký tự, luôn giữ tin cuối"""
    from aichat.chat_session import ChatSession
    s = ChatSession()
    for i in range(10):
        s.add("user", "u%d" % i + "x" * 100)
        s.add("model", "m%d" % i + "y" * 100)
    s.add("user", "cuối")
    c, trimmed = s.build_contents(500)
    eq(trimmed, True)
    eq(c[-1]["parts"][0]["text"], "cuối")
    eq(c[0]["role"], "user")


@test("Hội thoại")
def t_session_separate():
    """Hai phiên (Chat mới) có id khác nhau, không dùng chung lịch sử"""
    from aichat.chat_session import ChatSession
    a, b = ChatSession(), ChatSession()
    a.add("user", "x")
    assert a.id != b.id and b.items == []


@test("Gemini API (mock)")
def t_api_stream():
    """Streaming: nhận đủ nội dung, lọc phần 'thought', key nằm trong header"""
    from aichat.gemini_client import GeminiClient
    ev = []
    full, fin = GeminiClient(MOCK["key"], "gemini-3.8-flash", 10).stream(user("Xin chào"), "sys",
                                                                        lambda k, p: ev.append(k))
    eq(fin, "STOP")
    assert "suy nghĩ nội bộ" not in full and "Xin chào" in full
    assert ev[0] == "waiting" and "text" in ev
    r = mock_requests()[-1]
    assert r["has_key_header"] and not r["key_in_url"], "API key phải nằm trong header"


@test("Gemini API (mock)")
def t_api_errors():
    """Lỗi: key sai, hết hạn mức 429, sai mô hình 404, JSON hỏng"""
    from aichat.gemini_client import GeminiClient, GeminiError
    cases = [(lambda: GeminiClient("AIzaWRONG-xxxxxxxxxxxxxxxxxxxxxxxxxxxx", "m", 5).list_models(), "invalid_key"),
             (lambda: GeminiClient(MOCK["key"], "m", 5).stream(user("LOI429")), "quota"),
             (lambda: GeminiClient(MOCK["key"], "khong-ton-tai", 5).stream(user("x")), "not_found"),
             (lambda: GeminiClient(MOCK["key"], "m", 5).stream(user("JSONHONG")), "invalid_response")]
    for fn, kind in cases:
        try:
            fn()
            raise AssertionError("không báo lỗi " + kind)
        except GeminiError as e:
            eq(e.kind, kind)


@test("Gemini API (mock)")
def t_api_retry():
    """Quá tải 503: tự thử lại rồi thành công; quá tải liên tục thì báo lỗi"""
    from aichat import gemini_client as g
    old = list(g.RETRY_DELAYS)
    g.RETRY_DELAYS[:] = [0.1, 0.1]
    try:
        ev = []
        g.GeminiClient(MOCK["key"], "qua-tai", 5).stream(user("x"), None, lambda k, p: ev.append((k, p)))
        eq([e for e in ev if e[0] == "retry"], [("retry", 1), ("retry", 2)])
        try:
            g.GeminiClient(MOCK["key"], "luon-qua-tai", 5).stream(user("x"))
            raise AssertionError("không báo lỗi")
        except g.GeminiError as e:
            eq(e.kind, "overloaded")
    finally:
        g.RETRY_DELAYS[:] = old


@test("Gemini API (mock)")
def t_api_timeout_offline():
    """Hết thời gian chờ và mất kết nối được báo đúng loại lỗi"""
    from aichat.gemini_client import GeminiClient, GeminiError
    try:
        GeminiClient(MOCK["key"], "m", 1).stream(user("CHAM"))
        raise AssertionError("không timeout")
    except GeminiError as e:
        eq(e.kind, "timeout")
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    old = os.environ["AICHAT_TEST_BASE_URL"]
    os.environ["AICHAT_TEST_BASE_URL"] = "http://127.0.0.1:%d/v1beta" % port
    try:
        GeminiClient(MOCK["key"], "m", 3).list_models()
        raise AssertionError("không báo mất kết nối")
    except GeminiError as e:
        eq(e.kind, "offline")
    finally:
        os.environ["AICHAT_TEST_BASE_URL"] = old


@test("Gemini API (mock)")
def t_api_no_foreign_host():
    """Không cho phép gửi key tới máy chủ khác ngoài Google (trừ localhost khi test)"""
    from aichat import gemini_client as g
    old = os.environ["AICHAT_TEST_BASE_URL"]
    os.environ["AICHAT_TEST_BASE_URL"] = "https://evil.example.com/v1beta"
    try:
        eq(g._base_url(), g.OFFICIAL_BASE_URL)
    finally:
        os.environ["AICHAT_TEST_BASE_URL"] = old


@test("Gemini API (mock)")
def t_api_connection_test():
    """Kiểm tra kết nối 2 bước: bước 1 (key) / bước 2 (mô hình)"""
    from aichat import gemini_client as g
    models, reply, _ = g.test_connection(MOCK["key"], "gemini-3.8-flash")
    eq(reply, "OK")
    assert "gemini-3.8-flash" in models and not any("embedding" in m for m in models)
    for key, model, stage in (("AIzaWRONG-xxxxxxxxxxxxxxxxxxxxxxxxxxxx", "m", 1), (MOCK["key"], "khong-ton-tai", 2)):
        try:
            g.test_connection(key, model)
            raise AssertionError("không lỗi")
        except g.StageError as e:
            eq(e.stage, stage)


@test("Viết lại / Dịch (JSON)")
def t_structured():
    """Tách result/notes, chịu được ```json, từ chối phản hồi không phải JSON"""
    from aichat.prompts import parse_structured, partial_result
    raw = json.dumps({"result": "Bản dịch\nDòng 2", "notes": "ghi chú"}, ensure_ascii=False)
    eq(parse_structured(raw), ("Bản dịch\nDòng 2", "ghi chú"))
    eq(parse_structured("```json\n" + raw + "\n```"), ("Bản dịch\nDòng 2", "ghi chú"))
    eq(parse_structured("Dưới đây là bản dịch: ..."), None)
    eq(partial_result(raw[:len('{"result": "Bản')]), "Bản")       # JSON còn đang truyền dở


@test("Viết lại / Dịch (JSON)")
def t_structured_api():
    """Gửi kèm responseJsonSchema và nhận result không có lời dẫn"""
    from aichat.gemini_client import GeminiClient
    from aichat.prompts import build_message, parse_structured, structured_config, STRUCTURED_RULES, ACTIONS
    from aichat.document import Snapshot
    msg = build_message(ACTIONS["translate"][1], Snapshot("Xin chào\nTạm biệt", "text"), STRUCTURED_RULES)
    full, _ = GeminiClient(MOCK["key"], "m", 10).stream(user(msg), None, None, None, structured_config())
    eq(parse_structured(full)[0], "[EN] Xin chào\n[EN] Tạm biệt")
    eq(mock_requests()[-1]["body"]["generationConfig"]["responseMimeType"], "application/json")


@test("Đọc vùng chọn")
def t_snapshot_multi():
    """Nhiều vùng chọn rời nhau được nối có dấu phân cách, đếm đoạn đúng"""
    from aichat.document import read_selection

    class R(object):
        def __init__(s, t):
            s.t = t

        def getString(s):
            return s.t

    class Sel(object):
        def __init__(s, p):
            s.p = [R(x) for x in p]

        def supportsService(s, n):
            return n == "com.sun.star.text.TextRanges"

        def getCount(s):
            return len(s.p)

        def getByIndex(s, i):
            return s.p[i]

    class M(object):
        def supportsService(s, n):
            return n == "com.sun.star.text.TextDocument"

    class C(object):
        def getModel(s):
            return M()

        def getSelection(s):
            return Sel(["A\r\nB", "", "C"])

    class F(object):
        def getController(s):
            return C()

    snap = read_selection(F())
    eq((snap.kind, snap.parts, snap.paragraphs, snap.text), ("multi", 2, 3, "A\nB\n\n[…]\n\nC"))


# =============================================================== TÍCH HỢP LIBREOFFICE (UNO)
LO = {}


def find_soffice():
    if "--soffice" in ARGS:
        return ARGS[ARGS.index("--soffice") + 1]
    exe = "soffice.exe" if os.name == "nt" else "soffice"
    cand = os.path.join(os.path.dirname(sys.executable), exe)   # python.exe của LibreOffice
    if os.path.exists(cand):
        return cand
    return shutil.which("soffice") or shutil.which("libreoffice")


def start_lo():
    try:
        import uno  # noqa
    except ImportError:
        raise EnvError("Python này không có module 'uno' – hãy chạy bằng python của LibreOffice")
    exe = find_soffice()
    if not exe:
        raise EnvError("Không tìm thấy soffice (dùng --soffice PATH)")
    import uno
    prof = tempfile.mkdtemp(prefix="aichat_lo_profile_")
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    proc = subprocess.Popen([exe, "--headless", "--norestore", "--nologo", "--nodefault",
                             "-env:UserInstallation=" + uno.systemPathToFileUrl(prof),
                             "--accept=socket,host=127.0.0.1,port=%d;urp;" % port],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    local = uno.getComponentContext()
    res = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
    ctx = None
    for _ in range(120):
        try:
            ctx = res.resolve("uno:socket,host=127.0.0.1,port=%d;urp;StarOffice.ComponentContext" % port)
            break
        except Exception:
            if proc.poll() is not None:
                break
            time.sleep(0.5)
    if ctx is None:
        proc.kill()
        raise EnvError("Không kết nối được LibreOffice headless")
    LO.update(ctx=ctx, proc=proc, prof=prof,
              desk=ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop", ctx))


def stop_lo():
    if not LO:
        return
    try:
        LO["desk"].terminate()
    except Exception:
        pass
    try:
        LO["proc"].wait(15)
    except Exception:
        LO["proc"].kill()
    shutil.rmtree(LO["prof"], ignore_errors=True)


class Doc(object):
    """Tài liệu mẫu (docfix): 4 đoạn tiếng Việt + 1 bảng; tự đóng khi xong."""

    def __enter__(self):
        import docfix
        self.fx = docfix
        self.doc = LO["desk"].loadComponentFromURL("private:factory/swriter", "_blank", 0, ())
        docfix.build(self.doc)
        self.frame = self.doc.CurrentController.Frame
        return self

    def __exit__(self, *a):
        try:
            self.doc.close(True)
        except Exception:
            pass

    def paras(self):
        out, e = [], self.doc.Text.createEnumeration()
        while e.hasMoreElements():
            p = e.nextElement()
            if p.supportsService("com.sun.star.text.Paragraph"):
                out.append(p)
        return out

    def texts(self):
        return [p.getString() for p in self.paras()]


@test("Đọc vùng chọn", needs_uno=True)
def u_read():
    """Một câu, nhiều đoạn, ô bảng khớp chính xác; không chọn -> báo lỗi; tài liệu không bị sửa"""
    from aichat.document import read_selection, SelectionError
    with Doc() as d:
        d.fx.select_paras(d.doc, 0, 0)
        eq(read_selection(d.frame).text, d.fx.PARAS[0])
        d.fx.select_paras(d.doc, 1, 3)
        eq(read_selection(d.frame).text, "\n".join(d.fx.PARAS[1:4]))
        d.fx.select_cells(d.doc, d.doc.TextTables.getByIndex(0))
        s = read_selection(d.frame)
        eq((s.kind, s.text), ("table", "Tỉnh\tDân số\nHuế\t1.2 triệu"))
        d.fx.select_none(d.doc)
        try:
            read_selection(d.frame)
            raise AssertionError("không báo lỗi khi chưa chọn")
        except SelectionError:
            pass
        eq(d.doc.isModified(), False, "đọc vùng chọn không được sửa tài liệu")


@test("Neo vùng gốc", needs_uno=True)
def u_anchor():
    """Cho phép khi không đổi / sửa phía trước / đổi vùng chọn; từ chối khi sửa, xóa, đóng tài liệu"""
    from aichat.document import read_selection, SelectionError

    def outcome(mutate):
        with Doc() as d:
            d.fx.select_paras(d.doc, 1, 2)
            snap = read_selection(d.frame)
            mutate(d)
            try:
                snap.locate_for_replace(d.frame)
                return "ok"
            except SelectionError:
                return "refuse"

    def edit_inside(d):
        c = d.doc.Text.createTextCursorByRange(d.fx.para_range(d.doc, 1, 1).getStart())
        c.goRight(3, False)
        d.doc.Text.insertString(c, "!!", False)

    eq(outcome(lambda d: None), "ok")
    eq(outcome(lambda d: d.doc.Text.insertString(d.doc.Text.getStart(), "Thêm. ", False)), "ok", "sửa phía trước")
    eq(outcome(lambda d: d.fx.select_paras(d.doc, 3, 3)), "ok", "đổi vùng chọn")
    eq(outcome(edit_inside), "refuse", "sửa bên trong")
    eq(outcome(lambda d: d.fx.para_range(d.doc, 1, 2).setString("")), "refuse", "xóa vùng gốc")
    with Doc() as d:
        d.fx.select_paras(d.doc, 1, 1)
        snap = read_selection(d.frame)
        frame = d.frame
    try:
        snap.locate_for_replace(frame)
        raise AssertionError("không từ chối khi tài liệu đã đóng")
    except SelectionError:
        pass


MD = "# T1\n## T2\n### T3\nCó **đậm**, *nghiêng*, `mã`.\n- a\n  - b\n1. x\n2. y\n```\ncode\n```\nHết."


@test("Chèn văn bản", needs_uno=True)
def u_insert_positions():
    """Chèn đầu / giữa câu / giữa tài liệu / cuối: đúng vị trí, nội dung cũ còn nguyên"""
    from aichat.writer_insert import insert_markdown, run_as_single_undo
    with Doc() as d:
        run_as_single_undo(d.doc, "t", lambda: insert_markdown(d.doc, d.doc.Text.getStart(), MD))
        eq(d.texts()[:3], ["T1", "T2", "T3"])
        eq(d.texts()[10:14], d.fx.PARAS)   # MD có 10 đoạn, nội dung cũ đứng ngay sau
    with Doc() as d:
        c = d.doc.Text.createTextCursorByRange(d.fx.para_range(d.doc, 0, 0).getStart())
        c.goRight(7, False)
        run_as_single_undo(d.doc, "t", lambda: insert_markdown(d.doc, c, "rất **đẹp** "))
        eq(d.texts()[0], "Hà Nội rất đẹp là thủ đô của Việt Nam.")
    with Doc() as d:
        c = d.doc.Text.createTextCursorByRange(d.fx.para_range(d.doc, 1, 1).getStart())
        c.goRight(10, False)
        run_as_single_undo(d.doc, "t", lambda: insert_markdown(d.doc, c, "## M\n- a"))
        eq(d.texts()[1:5], ["Thành phố ", "M", "a", d.fx.PARAS[1][10:]])
    with Doc() as d:
        run_as_single_undo(d.doc, "t", lambda: insert_markdown(d.doc, d.fx.para_range(d.doc, 3, 3).getEnd(), "### P\n1. x"))
        eq(d.texts()[3:6], [d.fx.PARAS[3], "P", "x"])


@test("Chèn văn bản", needs_uno=True)
def u_insert_formatting():
    """Markdown -> Heading 1-3, danh sách Writer thật, đậm/nghiêng, font code, Preformatted Text"""
    from aichat.writer_insert import insert_markdown, run_as_single_undo
    with Doc() as d:
        run_as_single_undo(d.doc, "t", lambda: insert_markdown(d.doc, d.doc.Text.getStart(), MD))
        p = d.paras()
        eq([x.ParaStyleName for x in p[:3]], ["Heading 1", "Heading 2", "Heading 3"])
        eq([(x.NumberingStyleName, x.NumberingLevel) for x in p[4:8]],
           [("List 1", 0), ("List 1", 1), ("Numbering 123", 0), ("Numbering 123", 0)])
        eq(p[8].ParaStyleName, "Preformatted Text")
        eq(p[9].NumberingStyleName or "", "", "đoạn sau danh sách không bị dính danh sách")
        runs, e = {}, p[3].createEnumeration()
        while e.hasMoreElements():
            r = e.nextElement()
            runs[r.getString()] = (r.CharWeight, r.CharPosture.value, r.CharFontName)
        eq(runs["đậm"][0], 150.0)
        eq(runs["nghiêng"][1], "ITALIC")
        eq(runs["mã"][2], "Liberation Mono")
        assert "**" not in d.doc.Text.getString() and "`" not in d.doc.Text.getString(), "còn ký hiệu Markdown"


@test("Thay thế văn bản", needs_uno=True)
def u_replace():
    """Thay một câu và nhiều đoạn đúng chỗ, phần còn lại không đổi"""
    from aichat.document import read_selection
    from aichat.writer_insert import replace_range, run_as_single_undo
    with Doc() as d:
        d.fx.select_paras(d.doc, 0, 0)
        doc, a = read_selection(d.frame).locate_for_replace(d.frame)
        run_as_single_undo(doc, "t", lambda: replace_range(doc, a, "Câu **mới**."))
        eq(d.texts()[:2], ["Câu mới.", d.fx.PARAS[1]])
    with Doc() as d:
        d.fx.select_paras(d.doc, 1, 3)
        doc, a = read_selection(d.frame).locate_for_replace(d.frame)
        run_as_single_undo(doc, "t", lambda: replace_range(doc, a, "Một\nHai"))
        eq(d.texts()[:4], [d.fx.PARAS[0], "Một", "Hai", ""])


@test("Undo", needs_uno=True)
def u_undo_single_step():
    """Chèn và thay thế đều chỉ thêm MỘT bước Undo; một lần undo khôi phục nguyên trạng"""
    from aichat.document import read_selection
    from aichat.writer_insert import insert_markdown, replace_range, run_as_single_undo
    with Doc() as d:
        um = d.doc.getUndoManager()
        before, n0 = d.texts(), len(um.getAllUndoActionTitles())
        run_as_single_undo(d.doc, "AI Chat: Chèn nội dung", lambda: insert_markdown(d.doc, d.doc.Text.getStart(), MD))
        eq(len(um.getAllUndoActionTitles()) - n0, 1)
        um.undo()
        eq(d.texts(), before)
        d.fx.select_paras(d.doc, 1, 2)
        doc, a = read_selection(d.frame).locate_for_replace(d.frame)
        run_as_single_undo(doc, "AI Chat: Thay thế đoạn văn", lambda: replace_range(doc, a, "# X\n- y\nz"))
        eq(um.getCurrentUndoActionTitle(), "AI Chat: Thay thế đoạn văn")
        um.undo()
        eq(d.texts(), before)


@test("Undo", needs_uno=True)
def u_undo_rollback():
    """Lỗi giữa chừng: tự hoàn tác phần đã ghi, không để lại bước undo rỗng"""
    from aichat.writer_insert import insert_markdown, run_as_single_undo, EditError
    with Doc() as d:
        um = d.doc.getUndoManager()
        before, n0 = d.doc.Text.getString(), len(um.getAllUndoActionTitles())

        def bad():
            insert_markdown(d.doc, d.doc.Text.getStart(), "# A\nB")
            raise RuntimeError("giả lập lỗi")
        try:
            run_as_single_undo(d.doc, "t-loi", bad)
            raise AssertionError("không báo lỗi")
        except EditError:
            pass
        eq(d.doc.Text.getString(), before)
        eq(len(um.getAllUndoActionTitles()), n0)


@test("Clipboard", needs_uno=True)
def u_clipboard():
    """Copy câu ngắn và văn bản dài (~20.000 ký tự có dấu), đọc lại khớp"""
    from aichat.clipboard import copy_text, read_text
    for text in ("Ngắn ✓", "\n".join("Dòng %d – tiếng Việt có dấu" % i for i in range(600))):
        copy_text(LO["ctx"], text)
        back = read_text(LO["ctx"])
        if back is None:
            raise EnvError("Clipboard không khả dụng ở chế độ headless của hệ thống này")
        eq(back.replace("\r\n", "\n"), text)


@test("Cài đặt", needs_uno=True)
def u_settings():
    """Lưu/đọc lại; giá trị sai kiểu dùng mặc định; file không chứa API key"""
    from aichat import settings
    ctx = LO["ctx"]
    cfg = settings.load(ctx)
    cfg["model"], cfg["system_prompt"] = "gemini-3.5-flash-lite", "Prompt thử ✓"
    settings.save(ctx, cfg)
    again = settings.load(ctx)
    eq((again["model"], again["system_prompt"]), ("gemini-3.5-flash-lite", "Prompt thử ✓"))
    path = settings._settings_path(ctx)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"model": 123, "timeout": "abc"}, f)
    bad = settings.load(ctx)
    eq((bad["model"], bad["timeout"]), (settings.DEFAULTS["model"], settings.DEFAULTS["timeout"]))
    with open(path, "w", encoding="utf-8") as f:
        f.write("{hỏng")
    eq(settings.load(ctx)["model"], settings.DEFAULTS["model"], "file hỏng -> mặc định")
    settings.save(ctx, settings.DEFAULTS)
    with open(path, encoding="utf-8") as f:
        assert "AIza" not in f.read() and "key" not in json.load(open(path, encoding="utf-8"))


@test("Lưu API key", needs_uno=True)
def u_secret_store():
    """Windows: Credential Manager thật (mục thử riêng). Hệ khác: kho mật khẩu LibreOffice"""
    from aichat import secret_store as ss
    key = "AIzaTEST-" + "k" * 30
    if sys.platform.startswith("win"):
        old = ss.TARGET
        ss.TARGET = "LibreOffice AI Chat/Gemini-TEST"   # không đụng tới key thật của người dùng
        try:
            st = ss.WindowsCredentialStore()
            st.save(key)
            eq(st.load(), key)
            st.delete()
            eq(st.load(), "")
        finally:
            ss.TARGET = old
    else:
        st = ss.LibreOfficePasswordStore(LO["ctx"])
        st.save(key)
        eq(st.load(), key)
        st.delete()
        eq(st.load(), "")


# =============================================================== HIỆU NĂNG (--perf)
def _fodt(path, pages):
    """Tạo tài liệu ~pages trang A4 (mỗi trang ~1 tiêu đề + 12 đoạn tiếng Việt)."""
    body = []
    para = ("Hà Nội là thủ đô của Việt Nam, thành phố có lịch sử hơn một nghìn năm với nhiều di tích, "
            "danh lam thắng cảnh và nền văn hóa đặc sắc được gìn giữ qua nhiều thế hệ. ")
    for p in range(pages):
        body.append('<text:h text:style-name="Heading_20_2" text:outline-level="2">Mục %d</text:h>' % (p + 1))
        for i in range(12):
            body.append("<text:p>%s</text:p>" % (para * 2).strip())
    xml = ('<?xml version="1.0" encoding="UTF-8"?><office:document xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
           'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" office:version="1.3" '
           'office:mimetype="application/vnd.oasis.opendocument.text"><office:body><office:text>%s'
           '</office:text></office:body></office:document>' % "".join(body))
    with open(path, "w", encoding="utf-8") as f:
        f.write(xml)


def _rss_mb():
    """RAM của tiến trình soffice.bin thật (soffice chỉ là trình khởi chạy). Chỉ đo được trên Linux."""
    if not os.path.isdir("/proc"):
        return None
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            with open("/proc/%s/cmdline" % pid, "rb") as f:
                cmd = f.read().decode("utf-8", "replace")
            if "soffice.bin" in cmd and LO["prof"] in cmd:
                with open("/proc/%s/status" % pid) as f:
                    for line in f:
                        if line.startswith("VmRSS"):
                            return int(line.split()[1]) // 1024
        except Exception:
            continue
    return None


PERF_ROWS = []


@test("Tài liệu lớn", needs_uno=True, perf=True)
def p_large_docs():
    """Đọc vùng chọn, chèn, thay thế, undo trên tài liệu 50/100/200/500 trang"""
    import uno
    from aichat.document import read_selection
    from aichat.writer_insert import insert_markdown, replace_range, run_as_single_undo
    big_md = "\n".join(["## Kết quả"] + ["- mục **%d** với `mã`" % i for i in range(200)] + ["Đoạn kết."])
    for pages in (50, 100, 200, 500):
        path = os.path.join(tempfile.gettempdir(), "aichat_big_%d.fodt" % pages)
        _fodt(path, pages)
        t0 = time.time()
        doc = LO["desk"].loadComponentFromURL(uno.systemPathToFileUrl(path), "_blank", 0, ())
        t_load = time.time() - t0
        try:
            ctrl, frame = doc.CurrentController, doc.CurrentController.Frame
            real_pages = ctrl.PageCount
            # chọn 20 đoạn ở giữa tài liệu
            e, ps = doc.Text.createEnumeration(), []
            while e.hasMoreElements():
                ps.append(e.nextElement())
            mid = len(ps) // 2
            cur = doc.Text.createTextCursorByRange(ps[mid].getStart())
            cur.gotoRange(ps[mid + 19].getEnd(), True)
            ctrl.select(cur)
            original = doc.Text.getString()
            t0 = time.time()
            snap = read_selection(frame)
            t_read = time.time() - t0
            t0 = time.time()
            run_as_single_undo(doc, "AI Chat: Chèn nội dung",
                               lambda: insert_markdown(doc, ps[len(ps) // 4].getStart(), big_md))
            t_ins = time.time() - t0
            t0 = time.time()
            d2, a = snap.locate_for_replace(frame)
            run_as_single_undo(doc, "AI Chat: Thay thế đoạn văn", lambda: replace_range(doc, a, "Một\nHai\nBa"))
            t_rep = time.time() - t0
            um = doc.getUndoManager()
            t0 = time.time()
            um.undo()
            um.undo()
            t_undo = time.time() - t0
            eq(doc.Text.getString() == original, True, "sau 2 undo tài liệu phải về nguyên trạng (%d trang)" % pages)
            PERF_ROWS.append((pages, real_pages, len(ps), t_load, t_read, len(snap.text), t_ins, t_rep, t_undo, _rss_mb()))
        finally:
            doc.close(True)
            os.remove(path)
        assert t_read < 2 and t_ins < 10 and t_rep < 5, "quá chậm ở tài liệu %d trang" % pages


# =============================================================== CHẠY
def main():
    unit_only, perf = "--unit" in ARGS, "--perf" in ARGS
    print("AI Chat cho Writer – bộ kiểm thử tự động (Python %s, %s)\n" % (sys.version.split()[0], sys.platform))
    start_mock()
    lo_error = None
    if not unit_only and any(t[3] for t in TESTS):
        try:
            start_lo()
        except EnvError as e:
            lo_error = str(e)
    results = []
    try:
        for group, name, fn, needs_uno, is_perf in TESTS:
            if is_perf and not perf:
                continue
            if needs_uno and unit_only:
                continue
            t0 = time.time()
            if needs_uno and lo_error:
                status, detail = "ENV", lo_error
            else:
                try:
                    fn()
                    status, detail = "PASS", ""
                except Skip as e:
                    status, detail = "SKIP", str(e)
                except EnvError as e:
                    status, detail = "ENV", str(e)
                except AssertionError as e:
                    status, detail = "FAIL", str(e) or traceback.format_exc().splitlines()[-2]
                except Exception:
                    status, detail = "FAIL", traceback.format_exc() if VERBOSE else traceback.format_exc().splitlines()[-1]
            results.append((group, name, status, detail, time.time() - t0))
            print("[%-4s] %-26s %s (%.2fs)" % (status, group, name, time.time() - t0))
            if detail and status != "PASS":
                print("        " + detail.replace("\n", "\n        "))
    finally:
        stop_lo()
        MOCK["srv"].shutdown()
    if PERF_ROWS:
        print("\nHiệu năng tài liệu lớn (giây):")
        print("  %-6s %-6s %-7s %-7s %-12s %-8s %-8s %-7s %s" % ("trang", "thực", "đoạn", "mở", "đọc 20 đoạn", "chèn",
                                                              "thay", "2 undo", "RAM soffice"))
        for r in PERF_ROWS:
            print("  %-6d %-6d %-7d %-7.2f %-12s %-8.2f %-8.2f %-7.2f %s" % (
                r[0], r[1], r[2], r[3], "%.3f (%d kt)" % (r[4], r[5]), r[6], r[7], r[8],
                ("%d MB" % r[9]) if r[9] else "n/a"))
    counts = {}
    for r in results:
        counts[r[2]] = counts.get(r[2], 0) + 1
    print("\nTỔNG: " + "  ".join("%s=%d" % (k, counts.get(k, 0)) for k in ("PASS", "FAIL", "ENV", "SKIP")))
    if counts.get("ENV"):
        print("Ghi chú: ENV là lỗi môi trường (không phải lỗi extension). Kiểm tra cài đặt LibreOffice/Python.")
    sys.exit(1 if counts.get("FAIL") else 0)


if __name__ == "__main__":
    main()
