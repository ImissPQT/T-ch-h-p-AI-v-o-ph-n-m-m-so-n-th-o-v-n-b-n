# -*- coding: utf-8 -*-
"""Kiểm tra cài đặt / gỡ / cài lại extension trên một hồ sơ LibreOffice SẠCH (tạm thời).

Chạy:  python tests/install_test.py dist/LibreOffice_AI_Chat_1.0.0.oxt
(Windows: dùng python.exe của LibreOffice; Linux cần màn hình, vd. xvfb-run)

Dùng XExtensionManager (cùng API với Công cụ > Trình quản lý phần mở rộng), cài vào kho "user"
của hồ sơ tạm, khởi động lại LibreOffice sau mỗi bước và kiểm tra Sidebar thật có deck "AI Chat".
Không đụng tới hồ sơ LibreOffice đang dùng của bạn.
"""
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time

import uno
import unohelper
from com.sun.star.task import XInteractionHandler
from com.sun.star.ucb import XCommandEnvironment, XProgressHandler

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from run_tests import find_soffice  # noqa: E402

EXT_ID = "vn.aichat.writer"


class _Approve(unohelper.Base, XInteractionHandler):
    """Tự bấm 'Đồng ý' cho các hộp thoại xác nhận khi cài (giống người dùng bấm OK)."""

    def __init__(self):
        self.requests = []

    def handle(self, request):
        try:
            r = request.getRequest()
            self.requests.append(getattr(r, "typeName", None) or type(r).__name__)
        except Exception as e:  # một số yêu cầu không đọc được từ PyUNO -> vẫn xử lý tiếp
            self.requests.append("?")
        approve_t = uno.getTypeByName("com.sun.star.task.XInteractionApprove")
        conts = request.getContinuations()
        for c in conts:
            try:
                if c.queryInterface(approve_t) is not None:
                    c.select()
                    return
            except Exception:
                pass
        if conts:
            conts[0].select()


class _Progress(unohelper.Base, XProgressHandler):
    def push(self, s): pass
    def update(self, s): pass
    def pop(self): pass


class _Env(unohelper.Base, XCommandEnvironment):
    def __init__(self):
        self.handler = _Approve()

    def getInteractionHandler(self):
        return self.handler

    def getProgressHandler(self):
        return _Progress()


ENV = _Env()


class LO(object):
    def __init__(self, exe, profile_url):
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        self.port = s.getsockname()[1]
        s.close()
        self.proc = subprocess.Popen([exe, "--norestore", "--nologo", "--nodefault", "-env:UserInstallation=" + profile_url,
                                      "--accept=socket,host=127.0.0.1,port=%d;urp;" % self.port],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        local = uno.getComponentContext()
        res = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
        for _ in range(180):
            try:
                self.ctx = res.resolve("uno:socket,host=127.0.0.1,port=%d;urp;StarOffice.ComponentContext" % self.port)
                break
            except Exception:
                time.sleep(0.5)
        else:
            raise RuntimeError("Không kết nối được LibreOffice")
        self.desk = self.ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop", self.ctx)

    def ext_manager(self):
        return self.ctx.getValueByName("/singletons/com.sun.star.deployment.ExtensionManager")

    def installed_version(self):
        for pkgs in self.ext_manager().getAllExtensions(None, None):
            for p in pkgs:
                if p is not None and p.getIdentifier().Value == EXT_ID:
                    return p.getVersion()
        return None

    def sidebar_has_deck(self):
        doc = self.desk.loadComponentFromURL("private:factory/swriter", "_blank", 0, ())
        try:
            time.sleep(2)
            sb = doc.CurrentController.getSidebar()
            sb.setVisible(True)
            decks = sb.getDecks()
            if not decks.hasByName("AIChatDeck"):
                return False, None
            t0 = time.time()
            deck = decks.getByName("AIChatDeck")
            deck.activate(True)
            ok = "AIChatPanel" in deck.getPanels().getElementNames()
            return ok, time.time() - t0
        finally:
            doc.close(True)

    def stop(self):
        try:
            self.desk.terminate()
        except Exception:
            pass
        try:
            self.proc.wait(20)
        except Exception:
            self.proc.kill()


def main():
    oxt = os.path.abspath(sys.argv[1])
    exe = find_soffice()
    prof = tempfile.mkdtemp(prefix="aichat_clean_profile_")
    prof_url = uno.systemPathToFileUrl(prof)
    oxt_url = uno.systemPathToFileUrl(oxt)
    steps = []

    def step(name, ok, info=""):
        steps.append((name, ok))
        print("[%s] %s %s" % ("PASS" if ok else "FAIL", name, info))

    try:
        lo = LO(exe, prof_url)
        step("Hồ sơ sạch: chưa có extension", lo.installed_version() is None)
        lo.ext_manager().addExtension(oxt_url, (), "user", None, ENV)
        step("Cài đặt", lo.installed_version() is not None, "phiên bản " + str(lo.installed_version()))
        lo.stop()

        lo = LO(exe, prof_url)
        ok, t = lo.sidebar_has_deck()
        step("Sau khởi động lại: Sidebar có AI Chat, panel tạo được", ok, "(mở deck %.2fs)" % (t or 0))
        pkg = [p for ps in lo.ext_manager().getAllExtensions(None, None) for p in ps
               if p is not None and p.getIdentifier().Value == EXT_ID][0]
        lo.ext_manager().removeExtension(EXT_ID, pkg.getName(), "user", None, ENV)
        step("Gỡ cài đặt", lo.installed_version() is None)
        lo.stop()

        lo = LO(exe, prof_url)
        ok, _ = lo.sidebar_has_deck()
        step("Sau khi gỡ: Sidebar không còn AI Chat", not ok)
        lo.ext_manager().addExtension(oxt_url, (), "user", None, ENV)
        lo.stop()

        lo = LO(exe, prof_url)
        ok, t = lo.sidebar_has_deck()
        step("Cài lại: hoạt động bình thường", ok, "(mở deck %.2fs)" % (t or 0))
        lo.stop()
    finally:
        shutil.rmtree(prof, ignore_errors=True)
    failed = [n for n, ok in steps if not ok]
    print("\nTỔNG: PASS=%d FAIL=%d" % (len(steps) - len(failed), len(failed)))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
