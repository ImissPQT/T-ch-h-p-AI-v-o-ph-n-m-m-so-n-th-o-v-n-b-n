# AI Chat cho LibreOffice Writer – v0.2.0 (Giai đoạn 1–4: chat thật với Google Gemini)

## Cài đặt và chạy (Windows)

1. Gỡ bản cũ: Công cụ ▸ Trình quản lý phần mở rộng ▸ chọn "AI Chat cho Writer" ▸ Gỡ bỏ.
2. Thêm `AIChatWriter.oxt` ▸ khởi động lại LibreOffice.
3. Tạo API key miễn phí tại https://aistudio.google.com/apikey
4. Mở tab bong bóng chat ở Sidebar ▸ **Cài đặt** ▸ dán key ▸ **Lưu key** ▸ **Kiểm tra kết nối** ▸ **Lưu và đóng**.
5. Gõ câu hỏi ▸ **Gửi** (hoặc **Ctrl+Enter**). Khi đang chờ, nút đổi thành **Dừng**.

Kiểm tra key đã vào Windows Credential Manager: Control Panel ▸ Credential Manager ▸ Windows Credentials ▸
mục `LibreOffice AI Chat/Gemini`. Log lỗi: `%TEMP%\aichat_writer.log` (chỉ ghi loại lỗi, không ghi key/nội dung).

## Kiến trúc

```
ChatPanel (Sidebar, main thread)
  │ Gửi → ChatSession.build_contents()  (chỉ các lượt hỏi/đáp thành công, cắt bớt nếu quá dài)
  ▼
luồng nền: GeminiClient.stream()  ──HTTPS──▶  generativelanguage.googleapis.com
  │   POST /v1beta/models/{model}:streamGenerateContent?alt=sse
  │   header x-goog-api-key (key không nằm trong URL)
  ▼
AsyncCallback → main thread: vẽ từng đoạn trả lời, cập nhật trạng thái mỗi giây
```

## File

| File | Trạng thái | Vai trò |
|---|---|---|
| `python/aichat_component.py` | **sửa** | Thay Echo bằng Gemini; luồng nền; trạng thái; Dừng; Ctrl+Enter; Chat mới tách phiên; sửa lỗi lời chào bị khuất |
| `python/pythonpath/aichat/gemini_client.py` | mới | REST client (streaming), lọc phần "thought", chuyển mọi lỗi sang tiếng Việt |
| `python/pythonpath/aichat/secret_store.py` | mới | API key: Windows Credential Manager; dự phòng: kho mật khẩu LibreOffice |
| `python/pythonpath/aichat/settings.py` | mới | Cài đặt không bí mật (mô hình, system prompt) dạng JSON trong hồ sơ LibreOffice |
| `python/pythonpath/aichat/settings_dialog.py` | mới | Hộp thoại Cài đặt |
| `python/pythonpath/aichat/chat_session.py` | mới | Phiên hội thoại, ngữ cảnh, ngân sách độ dài |
| `python/pythonpath/aichat/markdown_text.py` | mới | Markdown → văn bản dễ đọc trong khung chat |
| `python/pythonpath/aichat/ui_async.py` | mới | Đưa kết quả từ luồng nền về main thread an toàn |
| `layout.py`, `ChatPanel.xdl`, `*.xcu`, `manifest.xml` | giữ nguyên | |
| `description.xml` | sửa | phiên bản 0.2.0 |

## Mô hình mặc định

`gemini-3.8-flash`. Theo trang giá chính thức (kiểm tra 11/2026), các mô hình Flash và Flash-Lite
(3.8, 3.6, 3.5-lite, 3.1-lite) đều có Free Tier. Có thể đổi mô hình hoặc **Tải danh sách** từ API trong Cài đặt.
Hạn mức Free Tier do Google quy định và có thể thay đổi; khi gặp lỗi 429, hãy chờ hoặc chuyển sang Flash-Lite.

## Bảo mật và quyền riêng tư

- Chỉ gửi tin nhắn người dùng gõ cùng lịch sử của phiên hiện tại; không đọc hay sửa tài liệu.
- Lời chào trong khung chat và hộp thoại Cài đặt đều thông báo: dữ liệu đi tới Google; với Free Tier,
  Google có thể dùng nội dung để cải thiện sản phẩm.
- Địa chỉ máy chủ cố định là của Google. Biến môi trường `AICHAT_TEST_BASE_URL` chỉ được chấp nhận khi trỏ tới
  `localhost` / `127.0.0.1` (dùng cho kiểm thử), nên key không thể bị gửi tới máy chủ trung gian.
