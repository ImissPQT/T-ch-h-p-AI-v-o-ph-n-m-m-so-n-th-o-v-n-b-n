# -*- coding: utf-8 -*-
"""Kết nối Google Gemini API qua HTTPS REST (không phụ thuộc UNO, không cần pip).

- Endpoint: https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent?alt=sse
- API key gửi bằng header `x-goog-api-key` (không nằm trong URL => không lộ qua log/proxy URL).
- Mọi lỗi đều được chuyển thành GeminiError với thông báo tiếng Việt dễ hiểu.
- Module này KHÔNG ghi log nội dung tin nhắn hay API key.
"""
import json
import os
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

OFFICIAL_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

# Danh sách gợi ý (đã kiểm tra trên trang giá chính thức 11/2026: đều có Free Tier).
# Người dùng có thể chọn mô hình khác hoặc tải danh sách thật từ API trong Cài đặt.
DEFAULT_MODEL = "gemini-3.8-flash"
SUGGESTED_MODELS = ["gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3.6-flash",
                    "gemini-3.1-flash-lite", "gemini-flash-latest"]

RETRY_DELAYS = [2, 5]  # giây chờ trước lần thử lại 1, 2
DEFAULT_TIMEOUT = 120  # giây; mô hình "thinking" có thể im lặng khá lâu trước token đầu tiên


def _base_url():
    """Chỉ cho phép đổi địa chỉ máy chủ sang localhost để KIỂM THỬ.

    Không có ô cấu hình nào trên giao diện => API key không thể vô tình bị gửi
    đến máy chủ trung gian.
    """
    override = os.environ.get("AICHAT_TEST_BASE_URL", "")
    if override.startswith("http://127.0.0.1:") or override.startswith("http://localhost:"):
        return override.rstrip("/")
    return OFFICIAL_BASE_URL


class GeminiError(Exception):
    """kind: invalid_key | permission | region | quota | too_large | bad_request |
    not_found | server | overloaded | timeout | offline | ssl | invalid_response |
    blocked | cancelled | no_key"""

    def __init__(self, kind, message, status=None, retry_after=None):
        Exception.__init__(self, message)
        self.kind = kind
        self.message = message
        self.status = status
        self.retry_after = retry_after


class Cancelled(GeminiError):
    def __init__(self):
        GeminiError.__init__(self, "cancelled", "Đã dừng yêu cầu.")


# ---------------------------------------------------------------- lỗi HTTP
def _parse_error_body(raw):
    try:
        err = json.loads(raw.decode("utf-8", "replace")).get("error", {})
    except Exception:
        return {}, "", ""
    reasons = []
    retry = None
    for d in err.get("details", []) or []:
        if isinstance(d, dict):
            if d.get("reason"):
                reasons.append(d["reason"])
            if d.get("retryDelay"):
                retry = d["retryDelay"]
    return {"reasons": reasons, "retry": retry}, err.get("message", "") or "", err.get("status", "") or ""


def _short(msg, n=300):
    msg = (msg or "").strip().replace("\n", " ")
    return msg if len(msg) <= n else msg[:n] + "…"


def error_from_http(code, raw_body, model=""):
    info, message, status = _parse_error_body(raw_body or b"")
    reasons = info.get("reasons", [])
    low = message.lower()
    retry = info.get("retry")

    if "API_KEY_INVALID" in reasons or "api key not valid" in low or "api key expired" in low:
        return GeminiError("invalid_key", "API key không hợp lệ hoặc đã hết hạn. Hãy kiểm tra lại trong Cài đặt "
                           "(tạo key mới tại aistudio.google.com/apikey).", code)
    if "location is not supported" in low or "user location" in low:
        return GeminiError("region", "Gemini API chưa hỗ trợ khu vực/mạng bạn đang dùng (lỗi vị trí từ Google).", code)
    if code == 429 or status == "RESOURCE_EXHAUSTED":
        wait = (" Có thể thử lại sau khoảng %s." % retry) if retry else ""
        return GeminiError("quota", "Đã chạm giới hạn của Free Tier (số yêu cầu mỗi phút/mỗi ngày hoặc số token)."
                           + wait + " Hãy chờ một lúc, hoặc chọn mô hình Flash-Lite trong Cài đặt.", code, retry)
    if code == 413 or ("token" in low and ("exceed" in low or "too long" in low or "limit" in low)):
        return GeminiError("too_large", "Nội dung quá dài so với giới hạn của mô hình. Hãy rút ngắn tin nhắn "
                           "hoặc bấm 'Chat mới' để bỏ bớt lịch sử hội thoại.", code)
    if code == 404 or status == "NOT_FOUND":
        return GeminiError("not_found", "Không tìm thấy mô hình '%s' (có thể đã ngừng hoạt động). "
                           "Vào Cài đặt > Tải danh sách để chọn mô hình khác." % model, code)
    if code in (401, 403) or status == "PERMISSION_DENIED":
        return GeminiError("permission", "API key không có quyền dùng Gemini API (key bị giới hạn, hoặc dự án chưa bật "
                           "Generative Language API). Chi tiết: " + _short(message), code)
    if code == 400:
        return GeminiError("bad_request", "Yêu cầu không hợp lệ: " + _short(message), code)
    if code == 503:
        return GeminiError("overloaded", "Mô hình '%s' đang quá tải phía Google (lỗi 503, đã tự thử lại). Hãy thử lại sau "
                           "ít phút, hoặc chọn mô hình nhẹ hơn như gemini-3.5-flash-lite trong Cài đặt." % model, code)
    if code == 504:
        return GeminiError("timeout", "Gemini xử lý quá lâu và đã hết thời gian chờ. Hãy thử lại.", code)
    if code >= 500:
        return GeminiError("server", "Máy chủ Gemini gặp lỗi (%d). Hãy thử lại sau." % code, code)
    return GeminiError("bad_request", "Lỗi HTTP %d: %s" % (code, _short(message)), code)


def error_from_network(exc):
    reason = getattr(exc, "reason", exc)
    if isinstance(reason, (socket.timeout, TimeoutError)) or "timed out" in str(reason).lower():
        return GeminiError("timeout", "Hết thời gian chờ phản hồi từ Gemini. Mô hình có thể đang chậm/quá tải, "
                           "hoặc mạng chập chờn. Thử lại, hoặc chọn gemini-3.5-flash-lite trong Cài đặt.")
    if isinstance(reason, ssl.SSLError) or "ssl" in str(reason).lower() or "certificate" in str(reason).lower():
        return GeminiError("ssl", "Lỗi bảo mật kết nối (SSL). Có thể do phần mềm diệt virus, proxy công ty "
                           "hoặc đồng hồ máy tính bị sai.")
    if isinstance(reason, socket.gaierror):
        return GeminiError("offline", "Không có kết nối Internet (không phân giải được tên máy chủ Google).")
    return GeminiError("offline", "Không kết nối được tới máy chủ Gemini. Kiểm tra Internet/tường lửa rồi thử lại.")


# ---------------------------------------------------------------- client
class GeminiClient(object):
    def __init__(self, api_key, model=DEFAULT_MODEL, timeout=DEFAULT_TIMEOUT):
        if not api_key:
            raise GeminiError("no_key", "Chưa có API key. Bấm 'Cài đặt' để nhập API key Gemini.")
        self._key = api_key
        self.model = (model or DEFAULT_MODEL).strip()
        if self.model.startswith("models/"):
            self.model = self.model[len("models/"):]
        self.timeout = timeout

    def __repr__(self):  # tránh lộ key nếu object bị in ra
        return "<GeminiClient model=%s>" % self.model

    def _request(self, method, path, body=None, query=None):
        url = _base_url() + path
        if query:
            url += "?" + urllib.parse.urlencode(query)
        data = None
        headers = {"x-goog-api-key": self._key, "Accept": "application/json"}
        if body is not None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json; charset=utf-8"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            return urllib.request.urlopen(req, timeout=self.timeout)
        except urllib.error.HTTPError as e:
            try:
                raw = e.read()
            except Exception:
                raw = b""
            raise error_from_http(e.code, raw, self.model)
        except (urllib.error.URLError, socket.timeout, TimeoutError, ssl.SSLError, ConnectionError, OSError) as e:
            raise error_from_network(e)

    def _post_with_retry(self, path, body, query=None, on_event=None, is_cancelled=None):
        """Tự thử lại tối đa 2 lần khi Google báo quá tải/lỗi máy chủ (503/500), trước khi có dữ liệu."""
        delays = RETRY_DELAYS
        for attempt in range(len(delays) + 1):
            try:
                return self._request("POST", path, body, query)
            except GeminiError as e:
                if e.kind not in ("overloaded", "server") or attempt >= len(delays):
                    raise
                if on_event:
                    on_event("retry", attempt + 1)
                end = time.time() + delays[attempt]
                while time.time() < end:
                    if is_cancelled and is_cancelled():
                        raise Cancelled()
                    time.sleep(0.2)

    # ---- danh sách mô hình (cũng dùng để kiểm tra key) ----
    def list_models(self):
        resp = self._request("GET", "/models", query={"pageSize": 1000})
        try:
            data = json.loads(resp.read().decode("utf-8"))
        except (ValueError, socket.timeout, OSError):
            raise GeminiError("invalid_response", "Phản hồi danh sách mô hình không hợp lệ.")
        finally:
            resp.close()
        skip = ("embedding", "image", "tts", "audio", "live", "transcribe", "aqa", "imagen", "veo", "lyria", "robotics")
        out = []
        for m in data.get("models", []) or []:
            name = (m.get("name") or "").replace("models/", "")
            methods = m.get("supportedGenerationMethods") or []
            if name.startswith("gemini") and "generateContent" in methods and not any(s in name for s in skip):
                out.append(name)
        return sorted(set(out), key=lambda s: (("flash" not in s), s))

    # ---- câu trả lời đầy đủ (dùng cho Kiểm tra kết nối) ----
    def generate(self, contents, system_instruction=None):
        body = self._body(contents, system_instruction)
        resp = self._post_with_retry("/models/%s:generateContent" % urllib.parse.quote(self.model), body)
        try:
            data = json.loads(resp.read().decode("utf-8"))
        except (ValueError, socket.timeout, OSError):
            raise GeminiError("invalid_response", "Gemini trả về dữ liệu không hợp lệ (không phải JSON).")
        finally:
            resp.close()
        text, finish = _extract(data)
        return text, finish

    # ---- streaming: gọi on_event(kind, payload) với kind = 'waiting' | 'text' ----
    def stream(self, contents, system_instruction=None, on_event=None, is_cancelled=None):
        on_event = on_event or (lambda k, p: None)
        is_cancelled = is_cancelled or (lambda: False)
        body = self._body(contents, system_instruction)
        resp = self._post_with_retry("/models/%s:streamGenerateContent" % urllib.parse.quote(self.model),
                                     body, {"alt": "sse"}, on_event, is_cancelled)
        on_event("waiting", None)  # đã kết nối, Gemini đang xử lý
        parts, finish = [], None
        try:
            for raw_line in resp:
                if is_cancelled():
                    raise Cancelled()
                line = raw_line.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if not payload or payload == "[DONE]":
                    continue
                try:
                    chunk = json.loads(payload)
                except ValueError:
                    raise GeminiError("invalid_response", "Gemini trả về dữ liệu không hợp lệ (JSON lỗi).")
                if "error" in chunk:
                    e = chunk["error"] or {}
                    raise error_from_http(int(e.get("code") or 500), json.dumps(chunk).encode("utf-8"), self.model)
                text, f = _extract(chunk, allow_empty=True)
                if f:
                    finish = f
                if text:
                    parts.append(text)
                    on_event("text", text)
        except (socket.timeout, TimeoutError):
            raise GeminiError("timeout", "Mất kết nối hoặc hết thời gian chờ khi đang nhận phản hồi.")
        except (ConnectionError, ssl.SSLError) as e:
            raise error_from_network(e)
        finally:
            resp.close()
        full = "".join(parts)
        if not full.strip():
            if finish in ("SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST", "SPII", "RECITATION"):
                raise GeminiError("blocked", "Gemini từ chối trả lời do bộ lọc an toàn/bản quyền (%s)." % finish)
            raise GeminiError("invalid_response", "Gemini không trả về nội dung nào (lý do: %s). Hãy thử lại." % (finish or "không rõ"))
        return full, finish

    def _body(self, contents, system_instruction):
        body = {"contents": contents}
        if system_instruction:
            body["systemInstruction"] = {"parts": [{"text": system_instruction}]}
        return body


def _extract(data, allow_empty=False):
    """Lấy text (bỏ phần 'thought') và finishReason từ một GenerateContentResponse."""
    if not isinstance(data, dict):
        raise GeminiError("invalid_response", "Cấu trúc phản hồi không hợp lệ.")
    fb = data.get("promptFeedback") or {}
    if fb.get("blockReason"):
        raise GeminiError("blocked", "Gemini chặn câu hỏi này do chính sách an toàn (%s)." % fb["blockReason"])
    cands = data.get("candidates")
    if not cands:
        if allow_empty:
            return "", None
        raise GeminiError("invalid_response", "Phản hồi không có câu trả lời (candidates rỗng).")
    cand = cands[0] or {}
    texts = []
    for p in ((cand.get("content") or {}).get("parts") or []):
        if isinstance(p, dict) and p.get("text") and not p.get("thought"):
            texts.append(p["text"])
    return "".join(texts), cand.get("finishReason")


class StageError(GeminiError):
    """Lỗi kèm bước kiểm tra bị hỏng: 1 = Internet/API key, 2 = mô hình."""

    def __init__(self, stage, err):
        GeminiError.__init__(self, err.kind, err.message, err.status, err.retry_after)
        self.stage = stage


def test_connection(api_key, model, on_stage=None):
    """Kiểm tra 2 bước, báo riêng bước nào hỏng.

    Bước 1: lấy danh sách mô hình (nhanh) -> xác nhận Internet + API key.
    Bước 2: hỏi mô hình đang chọn một câu ngắn (cho phép tới 60 giây vì mô hình có thể chậm).
    Trả về (models, reply, seconds_step2).
    """
    client = GeminiClient(api_key, model, timeout=20)
    try:
        models = client.list_models()
    except GeminiError as e:
        raise StageError(1, e)
    if on_stage:
        on_stage(1, models)
    client.timeout = 60
    t0 = time.time()
    try:
        reply, _ = client.generate([{"role": "user", "parts": [{"text": "Trả lời đúng một từ: OK"}]}])
    except GeminiError as e:
        raise StageError(2, e)
    return models, (reply or "").strip(), time.time() - t0
