# -*- coding: utf-8 -*-
"""Component UNO: factory tạo AI Chat Panel trong Sidebar của LibreOffice Writer.

Luồng hoạt động:
  Sidebar.xcu  -> ImplementationURL private:resource/toolpanel/AIChatPanelFactory/AIChatPanel
  Factories.xcu -> ánh xạ "AIChatPanelFactory" tới implementation vn.aichat.writer.PanelFactory
  PanelFactory.createUIElement() -> ChatPanel (XUIElement + XToolPanel + XSidebarPanel)

Giai đoạn 3-4: nút Gửi gọi Google Gemini API (HTTPS, streaming) ở luồng nền;
kết quả đưa về giao diện qua AsyncCallback để Writer không bị treo.
"""
import os
import sys
import tempfile
import threading
import time
import traceback

import uno
import unohelper
from com.sun.star.awt import XActionListener, XWindowListener, XKeyListener
from com.sun.star.lang import XComponent
from com.sun.star.ui import XUIElement, XToolPanel, XSidebarPanel, XUIElementFactory, LayoutSize

from aichat import EXTENSION_ID
from aichat.layout import layout

IMPL_NAME = "vn.aichat.writer.PanelFactory"
LOG_PATH = os.path.join(tempfile.gettempdir(), "aichat_writer.log")


def log(msg):
    """Ghi log ra %TEMP%/aichat_writer.log. KHÔNG bao giờ ghi API key hay nội dung tin nhắn."""
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg.rstrip() + "\n")
    except Exception:
        pass


# Các module dưới đây được import sau khi định nghĩa log() để lỗi import cũng được ghi lại
try:
    from aichat import settings
    from aichat.chat_session import ChatSession
    from aichat.gemini_client import GeminiClient, GeminiError
    from aichat.markdown_text import to_plain
    from aichat.secret_store import get_store
    from aichat.ui_async import MainThread, run_in_background
except Exception:
    log("Lỗi import module: " + traceback.format_exc())
    raise

INTRO = (
    "Xin chào! Hãy nhập câu hỏi rồi bấm Gửi (hoặc Ctrl+Enter).\n\n"
    "Lưu ý: tin nhắn được gửi tới Google Gemini API qua Internet và áp dụng chính sách dữ liệu của Google "
    "(với Free Tier, Google có thể dùng nội dung để cải thiện sản phẩm). Extension không tự gửi nội dung tài liệu."
)
NO_KEY_HINT = "Chưa có API key Gemini. Bấm 'Cài đặt' để nhập key (tạo miễn phí tại aistudio.google.com/apikey)."


def extension_url(ctx, relative):
    pip = ctx.getValueByName("/singletons/com.sun.star.deployment.PackageInformationProvider")
    return pip.getPackageLocation(EXTENSION_ID) + "/" + relative


class _ButtonListener(unohelper.Base, XActionListener):
    def __init__(self, callback):
        self._cb = callback

    def actionPerformed(self, ev):
        try:
            self._cb()
        except Exception:
            log(traceback.format_exc())

    def disposing(self, ev):
        pass


class _ResizeListener(unohelper.Base, XWindowListener):
    def __init__(self, panel):
        self._panel = panel

    def windowResized(self, ev):
        self._panel.relayout()

    def windowMoved(self, ev): pass
    def windowShown(self, ev): pass
    def windowHidden(self, ev): pass
    def disposing(self, ev): pass


class _CtrlEnterListener(unohelper.Base, XKeyListener):
    """Ctrl+Enter trong ô nhập = Gửi (Enter thường vẫn xuống dòng)."""

    def __init__(self, panel):
        self._panel = panel

    def keyPressed(self, ev):
        RETURN = uno.getConstantByName("com.sun.star.awt.Key.RETURN")
        MOD1 = uno.getConstantByName("com.sun.star.awt.KeyModifier.MOD1")
        if ev.KeyCode == RETURN and (ev.Modifiers & MOD1):
            try:
                self._panel.on_send(from_keyboard=True)
            except Exception:
                log(traceback.format_exc())

    def keyReleased(self, ev): pass
    def disposing(self, ev): pass


class _Request(object):
    """Trạng thái của MỘT yêu cầu đang chạy. Luồng nền chỉ ghi vào đây, không chạm UI."""

    def __init__(self, session_id):
        self.session_id = session_id
        self.t0 = time.time()
        self.phase = "sending"  # sending -> waiting -> receiving
        self.cancelled = False
        self.done = threading.Event()
        self.lock = threading.Lock()
        self.chunks = []
        self.flush_pending = False


class ChatPanel(unohelper.Base, XUIElement, XToolPanel, XSidebarPanel, XComponent):
    """Một panel cho mỗi cửa sổ Writer (mỗi Frame có một Sidebar riêng)."""

    def __init__(self, ctx, frame, parent_window, resource_url):
        self.ctx = ctx
        self.Frame = frame
        self.ResourceURL = resource_url
        self.Type = uno.getConstantByName("com.sun.star.ui.UIElementType.TOOLPANEL")
        self.parent = parent_window
        self.session = ChatSession()
        self.req = None           # _Request đang chạy (None = rảnh)
        self.disposed = False
        self.main = MainThread(ctx, log)

        provider = ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.awt.ContainerWindowProvider", ctx)
        self.Window = provider.createContainerWindow(
            extension_url(ctx, "dialogs/ChatPanel.xdl"), "", parent_window, None)
        self.Window.setVisible(True)

        self._listeners = []
        self._bind("btnSend", self.on_send)
        self._bind("btnNewChat", self.on_new_chat)
        self._bind("btnSettings", self.on_settings)
        self._key_listener = _CtrlEnterListener(self)
        self.ctl("txtInput").addKeyListener(self._key_listener)

        self._resize = _ResizeListener(self)
        parent_window.addWindowListener(self._resize)
        self.relayout()
        self.render_history()
        self.set_status("Sẵn sàng" if self._has_key() else "Chưa có API key – bấm Cài đặt")

    # ---------- tiện ích ----------
    def ctl(self, name):
        return self.Window.getControl(name)

    def _bind(self, name, cb):
        lst = _ButtonListener(cb)
        self._listeners.append(lst)
        self.ctl(name).addActionListener(lst)

    def set_status(self, text):
        if not self.disposed:
            self.ctl("lblStatus").getModel().Label = text

    def relayout(self):
        size = self.parent.getPosSize()
        self.Window.setPosSize(0, 0, size.Width, size.Height, 15)
        layout(self.Window, size.Width, size.Height)
        if size.Width > 0 and size.Height > 0:
            self._scroll_to_end()  # vị trí cuộn tính lúc panel còn 0x0 sẽ bị lệch -> tính lại

    def _load_key(self):
        try:
            return get_store(self.ctx).load()
        except Exception:
            log("secret_store.load: " + traceback.format_exc().splitlines()[-1])
            return ""

    def _has_key(self):
        return bool(self._load_key())

    def render_history(self):
        if self.disposed:
            return
        blocks = []
        for it in self.session.items:
            if it["role"] == "user":
                blocks.append("▶ Bạn\n" + it["text"])
            elif it["role"] == "model":
                body = to_plain(it["text"]) if it["text"] else "…"
                blocks.append("◆ Gemini\n" + body)
            else:
                blocks.append(it["text"])
        if not blocks:
            blocks.append(INTRO + ("" if self._has_key() else "\n\n" + NO_KEY_HINT))
        edit = self.ctl("txtHistory")
        text = "\n\n".join(blocks)
        edit.getModel().Text = text
        self._scroll_to_end()

    def _scroll_to_end(self):
        edit = self.ctl("txtHistory")
        n = len(edit.getModel().Text or "")
        Sel = "com.sun.star.awt.Selection"
        edit.setSelection(uno.createUnoStruct(Sel, 0, 0))
        edit.setSelection(uno.createUnoStruct(Sel, n, n))  # cuộn xuống tin nhắn mới nhất

    def _set_busy(self, busy):
        self.ctl("btnSend").getModel().Label = "Dừng" if busy else "Gửi"

    # ---------- gửi tin nhắn ----------
    def on_send(self, from_keyboard=False):
        if self.req is not None:
            if not from_keyboard:      # nút đang là "Dừng"
                self.cancel_request("Đã dừng theo yêu cầu.")
            return                     # chặn gửi trùng khi đang chờ
        model = self.ctl("txtInput").getModel()
        text = (model.Text or "").strip()
        if not text:
            return
        cfg = settings.load(self.ctx)
        if len(text) > cfg["max_message_chars"]:
            self.set_status("Tin nhắn quá dài (%d ký tự, tối đa %d)." % (len(text), cfg["max_message_chars"]))
            return
        key = self._load_key()
        if not key:
            self.session.add("note", "⚠ " + NO_KEY_HINT)
            self.render_history()
            self.set_status("Chưa có API key")
            return

        session = self.session
        user_item = session.add("user", text)
        contents, trimmed = session.build_contents(cfg["history_char_budget"])
        model_item = session.add("model", "", cfg["model"])
        model.Text = ""
        if from_keyboard:  # Enter của Ctrl+Enter được chèn sau sự kiện -> xóa lần nữa
            self.main.post(lambda: setattr(self.ctl("txtInput").getModel(), "Text", ""))

        req = self.req = _Request(session.id)
        req.user_item, req.model_item, req.trimmed, req.text = user_item, model_item, trimmed, text
        req.model_name = cfg["model"]
        self._set_busy(True)
        self.render_history()
        self.set_status("Đang gửi yêu cầu tới Gemini...")

        system_prompt, timeout = cfg["system_prompt"], cfg["timeout"]

        def on_event(kind, payload):           # chạy ở luồng nền
            if kind == "waiting":
                req.phase = "waiting"
            elif kind == "retry":
                req.phase = "retry"
                req.retry_n = payload
            elif kind == "text":
                req.phase = "receiving"
                with req.lock:
                    req.chunks.append(payload)
                    if req.flush_pending:
                        return
                    req.flush_pending = True
                time.sleep(0.08)               # gom nhiều đoạn nhỏ thành một lần vẽ
                self.main.post(lambda: self._flush(req))

        def work():                            # chạy ở luồng nền
            try:
                client = GeminiClient(key, req.model_name, timeout)
                full, finish = client.stream(contents, system_prompt, on_event, lambda: req.cancelled)
                self.main.post(lambda: self._finish_ok(req, full, finish))
            except GeminiError as e:
                log("gemini: %s (HTTP %s)" % (e.kind, e.status))
                kind, msg = e.kind, e.message
                self.main.post(lambda: self._finish_error(req, kind, msg))
            except Exception:
                log("gemini: lỗi không xác định\n" + traceback.format_exc())
                self.main.post(lambda: self._finish_error(req, "unknown", "Lỗi không xác định (xem file log)."))
            finally:
                req.done.set()

        def ticker():                          # cập nhật đồng hồ trạng thái mỗi giây
            while not req.done.wait(1.0):
                self.main.post(lambda: self._tick(req))

        run_in_background(work, "aichat-gemini")
        run_in_background(ticker, "aichat-ticker")

    def _current(self, req):
        return (not self.disposed and req is self.req and not req.cancelled
                and req.session_id == self.session.id)

    def _tick(self, req):
        if not self._current(req):
            return
        secs = int(time.time() - req.t0)
        label = {"sending": "Đang gửi yêu cầu", "waiting": "Gemini đang suy nghĩ",
                 "receiving": "Đang nhận phản hồi",
                 "retry": "Gemini quá tải, thử lại lần %d" % getattr(req, "retry_n", 1)}[req.phase]
        self.set_status("%s... %ds" % (label, secs))

    def _flush(self, req):
        with req.lock:
            req.flush_pending = False
            text = "".join(req.chunks)
        if not self._current(req):
            return
        req.model_item["text"] = text
        self.render_history()
        self._tick(req)

    def _finish_ok(self, req, full, finish):
        if not self._current(req):
            return
        req.model_item["text"] = full
        self.req = None
        self._set_busy(False)
        notes = []
        if finish == "MAX_TOKENS":
            notes.append("câu trả lời bị cắt do giới hạn độ dài")
        if req.trimmed:
            notes.append("đã lược bớt lịch sử cũ để vừa giới hạn")
        if notes:
            self.session.add("note", "ℹ " + "; ".join(notes).capitalize() + ".")
        self.render_history()
        self.set_status("Đã nhận phản hồi (%.1f giây)" % (time.time() - req.t0))

    def _finish_error(self, req, kind, msg):
        if not self._current(req):
            return
        self._rollback(req)
        self.session.add("note", "⚠ Lỗi: " + msg)
        self.render_history()
        self.set_status("Lỗi – nội dung đã được trả lại ô nhập, bấm Gửi để thử lại")

    def _rollback(self, req):
        """Bỏ lượt hỏi/đáp thất bại khỏi ngữ cảnh và trả câu hỏi về ô nhập để thử lại."""
        self.session.remove(req.model_item)
        self.session.remove(req.user_item)
        self.req = None
        self._set_busy(False)
        inp = self.ctl("txtInput").getModel()
        if not (inp.Text or "").strip():
            inp.Text = req.text

    def cancel_request(self, reason):
        req = self.req
        if req is None:
            return
        self._rollback(req)
        req.cancelled = True  # luồng nền tự dừng; kết quả muộn bị bỏ qua
        if reason:
            self.session.add("note", "ℹ " + reason)
        self.render_history()
        self.set_status(reason or "Sẵn sàng")

    # ---------- nút khác ----------
    def on_new_chat(self):
        if self.req is not None:
            self.req.cancelled = True
            self.req = None
            self._set_busy(False)
        self.session = ChatSession()   # phiên mới, không trộn với phiên cũ
        self.ctl("txtInput").getModel().Text = ""
        self.render_history()
        self.set_status("Đã tạo cuộc hội thoại mới")

    def on_settings(self):
        from aichat.settings_dialog import SettingsDialog
        try:
            parent = self.Frame.getContainerWindow() if self.Frame else None
            SettingsDialog(self.ctx, self.main, log, parent).execute()
        except Exception:
            log("settings dialog: " + traceback.format_exc())
            self.set_status("Không mở được Cài đặt (xem log)")
            return
        if self.req is None:
            self.render_history()
            self.set_status("Sẵn sàng – mô hình: %s" % settings.load(self.ctx)["model"]
                            if self._has_key() else "Chưa có API key – bấm Cài đặt")

    # ---------- XUIElement ----------
    def getRealInterface(self):
        return self

    # ---------- XToolPanel ----------
    def createAccessible(self, parent_accessible):
        return self.Window

    # ---------- XSidebarPanel ----------
    def getHeightForWidth(self, width):
        # Tối thiểu 300px, không giới hạn tối đa (-1) => panel giãn hết chiều cao Deck
        return LayoutSize(300, -1, 400)

    def getMinimalWidth(self):
        # Nhỏ hơn bề rộng Sidebar mặc định để không phát sinh thanh cuộn ngang
        return 160

    # ---------- XComponent ----------
    def dispose(self):
        self.disposed = True
        if self.req is not None:
            self.req.cancelled = True
        try:
            self.parent.removeWindowListener(self._resize)
            self.Window.dispose()
        except Exception:
            log(traceback.format_exc())

    def addEventListener(self, l): pass
    def removeEventListener(self, l): pass


class PanelFactory(unohelper.Base, XUIElementFactory):
    def __init__(self, ctx):
        self.ctx = ctx

    def createUIElement(self, url, args):
        try:
            props = {a.Name: a.Value for a in args}
            parent = props.get("ParentWindow")
            if parent is None:
                raise RuntimeError("Thiếu ParentWindow")
            if url.endswith("/AIChatPanel"):
                return ChatPanel(self.ctx, props.get("Frame"), parent, url)
            raise RuntimeError("Không hỗ trợ: " + url)
        except Exception:
            log(traceback.format_exc())
            raise


g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(
    PanelFactory, IMPL_NAME, ("com.sun.star.ui.UIElementFactory",))
