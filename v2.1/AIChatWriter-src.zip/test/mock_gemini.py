# Máy chủ GIẢ LẬP Gemini – CHỈ dùng để kiểm thử extension trong môi trường không có Internet.
# Không nằm trong extension. Ghi lại các request nhận được (không ghi key) vào /tmp/mock_requests.jsonl
import json, sys, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

GOOD_KEY = "AIzaTEST-good-key-0123456789abcdef"
LOG = "/tmp/mock_requests.jsonl"
COUNT = {}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _json(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _check_key(self):
        key = self.headers.get("x-goog-api-key")
        if key != GOOD_KEY:
            self._json(400, {"error": {"code": 400, "message": "API key not valid. Please pass a valid API key.",
                                       "status": "INVALID_ARGUMENT", "details": [{"reason": "API_KEY_INVALID"}]}})
            return False
        return True

    def do_GET(self):
        if not self._check_key():
            return
        if self.path.startswith("/v1beta/models"):
            self._json(200, {"models": [
                {"name": "models/gemini-3.8-flash", "supportedGenerationMethods": ["generateContent"]},
                {"name": "models/gemini-3.5-flash-lite", "supportedGenerationMethods": ["generateContent"]},
                {"name": "models/gemini-embedding-001", "supportedGenerationMethods": ["embedContent"]},
                {"name": "models/gemini-3.1-flash-image", "supportedGenerationMethods": ["generateContent"]}]})
        else:
            self._json(404, {})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))).decode("utf-8"))
        with open(LOG, "a") as f:
            f.write(json.dumps({"path": self.path, "has_key_header": bool(self.headers.get("x-goog-api-key")),
                                "key_in_url": GOOD_KEY in self.path, "body": body}, ensure_ascii=False) + "\n")
        if not self._check_key():
            return
        model = self.path.split("/models/")[1].split(":")[0]
        if model in ("qua-tai", "luon-qua-tai"):
            COUNT[model] = COUNT.get(model, 0) + 1
            if model == "luon-qua-tai" or COUNT[model] % 3 != 0:
                return self._json(503, {"error": {"code": 503, "message": "The model is overloaded.", "status": "UNAVAILABLE"}})
        if model == "khong-ton-tai":
            return self._json(404, {"error": {"code": 404, "message": "models/%s is not found" % model, "status": "NOT_FOUND"}})
        contents = body.get("contents", [])
        last = contents[-1]["parts"][0]["text"] if contents else ""
        if ":generateContent" in self.path:
            return self._json(200, {"candidates": [{"content": {"role": "model", "parts": [{"text": "OK"}]}, "finishReason": "STOP"}]})
        if "LOI429" in last:
            return self._json(429, {"error": {"code": 429, "message": "You exceeded your current quota.",
                                              "status": "RESOURCE_EXHAUSTED", "details": [{"retryDelay": "41s"}]}})
        # ---- SSE streaming ----
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Connection", "close")
        self.end_headers()

        def send(obj):
            self.wfile.write(("data: " + json.dumps(obj, ensure_ascii=False) + "\r\n\r\n").encode("utf-8"))
            self.wfile.flush()

        if "JSONHONG" in last:
            self.wfile.write(b"data: {khong phai json\r\n\r\n"); self.wfile.flush(); return
        delay = 4 if "CHAM" in last else 0.3
        time.sleep(delay)
        users = [c for c in contents if c["role"] == "user"]
        prev = users[-2]["parts"][0]["text"] if len(users) > 1 else "(không có)"
        send({"candidates": [{"content": {"role": "model", "parts": [{"text": "suy nghĩ nội bộ", "thought": True}]}}]})
        answer = ("## Trả lời từ Gemini (giả lập)\n\nBạn hỏi: **%s**\n\n"
                  "- Số lượt *người dùng* trong ngữ cảnh: %d\n- Câu hỏi trước: %s\n- System prompt: %s\n\n"
                  "```python\nprint(\"Xin chào\")\n```\nĐoạn văn thứ hai, có `code`." %
                  (last[:60], len(users), prev[:40], "có" if body.get("systemInstruction") else "không"))
        for i in range(0, len(answer), 25):
            send({"candidates": [{"content": {"role": "model", "parts": [{"text": answer[i:i + 25]}]}}]})
            time.sleep(0.05)
        send({"candidates": [{"content": {"role": "model", "parts": [{"text": ""}]}, "finishReason": "STOP"}],
              "usageMetadata": {"totalTokenCount": 123}})


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1]) if len(sys.argv) > 1 else 8765), H).serve_forever()
